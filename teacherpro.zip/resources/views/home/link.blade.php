@extends('master.home')




                @section('main_body')



                    <div id="maincontent" class="rows">
                        <div>


                            <div class="short-link shade">

                                <div class="pic">
                                    <img class="bg" src="/home/images/profile.svg" alt="">

                                    <img class="pro" src="{{asset('/src/avatar/'.$fclass->user->attr('avatar'))}}" alt="">
                                </div>

                                <div class="name">
                                    <span>استاد  :</span>
                                    <span>  {{$fclass->user->name}}</span>
                                </div>

                                <div class="licence">
                                    <span>       {{$fclass->name}}    </span>
                                </div>

                                <div class="text">
                                  <p>
                                      {{$fclass->user->name}}
                                      شما را به کلاس
                                      {{$fclass->name}}
                                      را دعوت کرده است
                                  </p>
                                </div>

                                <div class="link">
                                    <div class="button-container reight">
                                        @if(\Illuminate\Support\Facades\Auth::check())
                                            @if(\Illuminate\Support\Facades\Auth::user()->level=='teacher')
                                                <a href="{{route('teacher.dashboard')}}"   rel="nofollow" class="sign"> <span class="icon-user-add"></span>       ورود به پنل </a>
                                            @else
                                                <a href="{{route('student.dashboard')}}"   rel="nofollow" class="sign"> <span class="icon-user-add"></span>       ورود به پنل </a>

                                            @endif
                                        @else
                                            <span id="show_login" class="butt">قبول دعوت</span>

                                        @endif
                                    </div>
                                </div>

                                <div class="guide">
                                    <span class="title"> راهنمای استفاده از تیچر پرو  :</span>
                                    <a href="#">
                                        <i class="icon-movie"></i>
                                        <span>مشاهده آموزش</span>
                                    </a>
                                </div>


                            </div>


                        </div>
                    </div>




                @endsection







