<div id="sideteachernav">

    <div class="teacher-prfile">
        <div class="pic">
            <span class="percent">{{auth()->user()->percent()}} %</span>
            <img class="bg" src="/home/images/profile.svg" alt="">

        @if(auth()->user()->attr('avatar'))
                <img  class="pro"  src="{{asset('src/avatar/'.auth()->user()->attr('avatar'))}}" alt="">
            @else
                <img class="pro" src="/src/avatar/{{(auth()->user()->sex=='male')?'avatar_man.png':'avatar_woman.png'}}" alt="">
            @endif
            <i class="icon-info"></i>
        </div>
        <div class="name">
            {{auth()->user()->name}}
        </div>
        <div class="email"> {{auth()->user()->email}}   </div>
    </div>

    <div class="pishkhan-nav">
        <ul>
            <li class="{{((Route::currentRouteName()=='teacher.dashboard')?'active':'')}}"><a href="{{route('teacher.dashboard')}}"><i class="icon-dashboard"></i><span>پیشخوان</span></a></li>
            <li class="{{((Route::currentRouteName()=='teacher.classes')?'active':'')}}"><a href="{{route('teacher.classes')}}"><i class="icon-dcalass"></i><span>کلاس ها</span></a></li>
{{--            <li class="{{((Route::currentRouteName()=='teacher.setting')?'active':'')}}"><a href="{{route('teacher.setting')}}"><i class="icon-dsetting"></i><span>تنظیمات</span></a></li>--}}
            <li class="{{((Route::currentRouteName()=='teacher.plans')?'active':'')}}"><a href="{{route('teacher.plans')}}"><i class="icon-calender"></i><span>برنامه زمانی</span></a></li>
            <li class="{{((Route::currentRouteName()=='teacher.prices')?'active':'')}}"><a href="{{route('teacher.prices')}}"><i class="icon-dwallet"></i><span>  قیمت ها</span></a></li>
            <li class="{{((Route::currentRouteName()=='teacher.articles')?'active':'')}}"><a href="{{route('teacher.articles')}}"><i class="icon-dwallet"></i><span>مقالات  </span></a></li>
            <li class="{{((Route::currentRouteName()=='teacher.wallet')?'active':'')}}"><a href="{{route('teacher.wallet')}}"><i class="icon-dwallet"></i><span>کیف پول</span></a></li>
            <li class="{{((Route::currentRouteName()=='teacher.profile')?'active':'')}}"><a href="{{route('teacher.profile')}}"><i class="icon-dwallet"></i><span> حساب کاربری  </span></a></li>
            <li class="{{((Route::currentRouteName()=='teacher.lang')?'active':'')}}"><a href="{{route('teacher.lang')}}"><i class="icon-dwallet"></i><span>   زبان‌ها  </span></a></li>
        </ul>
    </div>

</div>
