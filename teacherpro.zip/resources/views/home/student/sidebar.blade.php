<div id="sideteachernav">

    <div class="teacher-prfile">
        <div class="pic">

            <img class="bg" src="/home/images/profile.svg" alt="">

        @if(auth()->user()->attr('avatar'))
                <img  class="pro"  src="{{asset('src/avatar/'.auth()->user()->attr('avatar'))}}" alt="">
            @else
                <img class="pro" src="/src/avatar/{{(auth()->user()->sex=='male')?'avatar_man.png':'avatar_woman.png'}}" alt="">
            @endif
            <form style="position:relative; z-index: 3" action="{{route('student.save.avatar',auth()->user()->id)}}" enctype="multipart/form-data" method="post">
                @csrf
                @method('post')
                <div class="lable-container" style="overflow: visible">
                    <input id="profile-file" name="avatar" class="avat" type="file" accept="image/*">
                    <label for="profile-file">
                        <i class="icon-info"></i>
                    </label>
                </div>
            </form>
        </div>
        <div class="name">
            {{auth()->user()->name}}
        </div>
        <div class="email"> {{auth()->user()->email}}   </div>
    </div>

    <div class="pishkhan-nav">
        <ul>
            <li class="{{((Route::currentRouteName()=='student.dashboard')?'active':'')}}"><a href="{{route('student.dashboard')}}"><i class="icon-dashboard"></i><span>پیشخوان</span></a></li>
            <li class="{{((Route::currentRouteName()=='student.wallet')?'active':'')}}"><a href="{{route('student.wallet')}}"><i class="icon-dwallet"></i><span>کیف پول</span></a></li>
            <li class="{{((Route::currentRouteName()=='student.profile')?'active':'')}}"><a href="{{route('student.profile')}}"><i class="icon-dwallet"></i><span> حساب کاربری  </span></a></li>
            <li class="{{((Route::currentRouteName()=='student.fave')?'active':'')}}"><a href="{{route('student.fave')}}"><i class="icon-dwallet"></i><span>   علاقه مندی ها  </span></a></li>
        </ul>
    </div>

</div>
