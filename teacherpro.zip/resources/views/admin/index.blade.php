@component('admin.section.content',['title'=>' داشبورد'])
    @slot('bread')
        <li class="breadcrumb-item">پنل مدیریت</li>
     @endslot

@endcomponent

