<div id="sideteachernav">

    <div class="teacher-prfile">
        <div class="pic">
            <span class="percent"> ۷۰%</span>
            <img class="bg" src="/home/images/profile.svg" alt="">

        <?php if(auth()->user()->attr('avatar')): ?>
                <img  class="pro"  src="<?php echo e(asset('src/avatar/'.auth()->user()->attr('avatar'))); ?>" alt="">
            <?php else: ?>
                <img class="pro" src="/src/avatar/<?php echo e((auth()->user()->sex=='male')?'avatar_man.png':'avatar_woman.png'); ?>" alt="">
            <?php endif; ?>
            <i class="icon-info"></i>
        </div>
        <div class="name">
            <?php echo e(auth()->user()->name); ?>

        </div>
        <div class="email"> <?php echo e(auth()->user()->email); ?>   </div>
    </div>

    <div class="pishkhan-nav">
        <ul>
            <li class="<?php echo e(((Route::currentRouteName()=='teacher.dashboard')?'active':'')); ?>"><a href="<?php echo e(route('teacher.dashboard')); ?>"><i class="icon-dashboard"></i><span>پیشخوان</span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='teacher.classes')?'active':'')); ?>"><a href="<?php echo e(route('teacher.classes')); ?>"><i class="icon-dcalass"></i><span>کلاس ها</span></a></li>

            <li class="<?php echo e(((Route::currentRouteName()=='teacher.plans')?'active':'')); ?>"><a href="<?php echo e(route('teacher.plans')); ?>"><i class="icon-calender"></i><span>برنامه زمانی</span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='teacher.prices')?'active':'')); ?>"><a href="<?php echo e(route('teacher.prices')); ?>"><i class="icon-dwallet"></i><span>  قیمت ها</span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='teacher.articles')?'active':'')); ?>"><a href="<?php echo e(route('teacher.articles')); ?>"><i class="icon-dwallet"></i><span>نوشته ها</span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='teacher.wallet')?'active':'')); ?>"><a href="<?php echo e(route('teacher.wallet')); ?>"><i class="icon-dwallet"></i><span>کیف پول</span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='teacher.profile')?'active':'')); ?>"><a href="<?php echo e(route('teacher.profile')); ?>"><i class="icon-dwallet"></i><span> حساب کاربری  </span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='teacher.lang')?'active':'')); ?>"><a href="<?php echo e(route('teacher.lang')); ?>"><i class="icon-dwallet"></i><span>   زبان‌ها  </span></a></li>
        </ul>
    </div>

</div>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/sidebar.blade.php ENDPATH**/ ?>
