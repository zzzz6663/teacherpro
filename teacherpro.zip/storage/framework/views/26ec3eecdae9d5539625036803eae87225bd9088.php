<?php if($paginator->lastPage() > 1): ?>

    <div class="pagination">
        <div class="number">


            <ul>





                <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
                    <li class="<?php echo e(($paginator->currentPage() == $i) ? ' active' : ''); ?>">
                        <a  href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>

            </ul>
        </div>
        <div class="result">
            <span>صفحه
<?php echo e($paginator->currentPage()); ?>

                از
               <?php echo e($paginator->lastPage()); ?>

            </span>
        </div>

        <div class="next-prev">

            <span class="next-page <?php echo e(($paginator->currentPage() == $paginator->lastPage()) ? ' disabled' : ''); ?>">

                <a href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>" >    <i class="icon-arrow-right-line"></i></a>

            </span>
            <span class="prev-page<?php echo e(($paginator->currentPage() == 1) ? ' disabled' : ''); ?> ">
                     <a href="<?php echo e($paginator->url($paginator->currentPage()-1)); ?>">  <i class="icon-arrow-right-line"></i></a>

            </span>
        </div>
    </div>

<?php endif; ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/section/pagination.blade.php ENDPATH**/ ?>