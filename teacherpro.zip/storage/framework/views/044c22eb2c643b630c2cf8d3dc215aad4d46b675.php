<?php $__env->startComponent('home.student.content',['title'=>' تنظیمات  ']); ?>


<div id="teacherpish">

    <?php $__env->slot('bread'); ?>

        <?php echo $__env->make('home.student.profile.bread_left',['name'=>'داشبورد'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php $__env->endSlot(); ?>


        <div id="stulist" class="shade">
            <div class="widget-title">
                <h3>انتخاب زمان برای کلاس های رزور شده</h3>
                <div class="dot3">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="widget-content">
                <ul class="stulist owl-carousel owl-theme">
                    <?php $__currentLoopData = \App\Models\Count::where('user_id',$user->id)->where('Count','>','0')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($teacher=\App\Models\User::find($count->teacher_id)); ?>
                        <li>
                            <div class="single-st">
                                <div class="pic">
                                    <img src="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>" alt="">
                                </div>
                                <div class="name">
                                    <h4>
                                        <?php echo e($teacher->name); ?>

                                    </h4>
                                </div>
                                <div class="time">
                                    <span>
                                        <?php echo e($count->count); ?>

                                        زمان رزرو نشده
                                    </span>
                                </div>
                                <div class="button">
											<span class="chtime" onclick="window.location.href='<?php echo e(route('student.reserve',[$teacher->id,$count->id])); ?>'">
												انتخاب زمان
											</span>
                                </div>
                            </div>
                        </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        </div>
        <?php ($classes=\App\Models\Meet::where('student_id',$user->id)->whereNull('pair')->where('canceled','0')->where('start','>',\Carbon\Carbon::now())->orderBy('start','asc')->paginate(5)); ?>
        <?php ($first=$classes->first()); ?>
        <?php
        $w=[  'شنبه' ,'یکشنبه','دوشنبه','سه شنبه','چهارشنبه','پنج شنبه','جمعه'];
        $m=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند' ];
        ?>
    <?php if($first): ?>
            <?php ($teacher=\App\Models\User::find($first->user_id)); ?>
            <?php ($v=verta($first->start)); ?>
            <?php
            $min="$v->minute";
            if ($v->minute==0){
                $min='00';

            }
            ?>
    <div id="nextclass" class="shade">
        <div class="widget-title">
            <h3>کلاس پیش رو</h3>
            <div class="dot3">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <div class="widget-content">
            <div class="right">
                <div class="stuprofile">
                    <div class="pic">
                        <span class="num1"></span>
                        <span class="num2"></span>
                        <span class="num3"></span>
                        <img src="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>" alt="">

                    </div>
                    <div class="detail">
                        <span>استاد</span>
                        <h4>    <?php echo e($teacher->name); ?> </h4>
                        <span class="date">
                                   <?php echo e($w[date('w', strtotime($first->start))]); ?>

                            <?php echo e(($v->day)); ?>

                            <?php echo e(($m[$v->month-1])); ?>

                            <?php echo e(($v->hour.':'.$min)); ?>


                        </span>
                    </div>
                </div>
            </div>
            <div class="left">
                <a target="_blank" class="bl start" href="<?php echo e(route('home.go.class',[$first->id])); ?>">
                    <span>شروع   کلاس</span>
                </a>

                <div id="countdown" data-time="<?php echo e($first->start); ?>"></div>

            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="class-list shade">
        <div class="widget-title">
            <h3>کلاس ها</h3>
            <form id="sort" action="<?php echo e(route('student.dashboard')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <?php echo method_field('get'); ?>
            <div class="time-filter">
                <span><i class="icon-time-line"></i>زمان </span>
                <select name="time" id="time">
                    <option <?php echo e((request()->get('time')=='today')?'selected':''); ?> value="today">امروز</option>
                    <option <?php echo e((request()->get('time')=='tomorrow')?'selected':''); ?> value="tomorrow">فردا</option>
                    <option <?php echo e((request()->get('time')=='dtomorrow')?'selected':''); ?> value="dtomorrow">پس فردا</option>
                </select>
            </div>
            </form>
                <form id="sta" action="<?php echo e(route('student.dashboard')); ?>" method="get">
            <div class="stat-filter">
                <span><i class="icon-stat"></i>وضعیت </span>
                <select name="status" id="status">
                    <option <?php echo e((request()->get('status')=='pioneer')?'selected':''); ?> value="pioneer">پیش رو</option>
                    <option <?php echo e((request()->get('status')=='down')?'selected':''); ?> value="down">انجام شده</option>
                    <option <?php echo e((request()->get('status')=='canceled')?'selected':''); ?> value="canceled">کنسل شده</option>
                </select>
            </div>
            </form>
            <div class="dot3">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="widget-content">
            <div class="class-list-title">
                <span>      <?php echo e(\App\Models\Meet::where('student_id',$user->id)->whereNull('pair')->where('canceled','0')->where('start','>',\Carbon\Carbon::now())->orderBy('start','asc')->count()); ?>

                    کلاس در برنامه دارید</span>
            </div>

         <?php
            $classes=\App\Models\Meet::where('student_id',$user->id)->whereNull('pair')->where('canceled','0')->where('start','>',\Carbon\Carbon::now());
            if (request()->get('time')){
                if(request()->get('time')=='tomorrow') {
                    $classes=$classes->where( function($q){
                        $q->where('start', '>',\Carbon\Carbon::now()->addDay()->startOfDay())
                            ->where('start', '<',\Carbon\Carbon::now()->addDay()->endOfDay());
                    });
                }
                if(request()->get('time')=='today') {
                    $classes=$classes->where( function($q){
                        $q->where('start', '>',\Carbon\Carbon::now()->startOfDay())
                            ->where('start', '<',\Carbon\Carbon::now()->endOfDay());
                    });
                }
                if(request()->get('time')=='dtomorrow') {
                    $classes=$classes->where( function($q){
                        $q->where('start', '>',\Carbon\Carbon::now()->addDays(2)->startOfDay())
                            ->where('start', '<',\Carbon\Carbon::now()->addDays(2)->endOfDay());
                    });
                }

            }
            if (request()->get('status')){
                $classes=\App\Models\Meet::where('student_id',$user->id)->whereNull('pair')->where('canceled','0');
                if(request()->get('status')=='pioneer') {
                    $classes=\App\Models\Meet::where('student_id',$user->id)->whereNull('pair')->where('canceled','0')->where('start','>',\Carbon\Carbon::now());
                }
                if(request()->get('status')=='down') {
                    $classes=$classes->where('status' ,'down' );
                }
                if(request()->get('status')=='canceled') {
                    $classes=$classes->where('status' ,'canceled' ) ;
                }

            }
            $classes=$classes->orderBy('start','asc')->paginate(5);
            ?>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($v=verta($class->start)); ?>
                <?php ($teacher=\App\Models\User::find($class->user_id)); ?>
                <?php
                $min="$v->minute";
                if ($v->minute==0){
                    $min='00';

                }
                ?>
            <div class="single-class">
                <div class="date">
                    <?php ($v=verta($class->start)); ?>


                    <span class="month">    <?php echo e(($m[$v->month-1])); ?></span>
                    <span class="day">    <?php echo e(($v->day)); ?></span>
                    <span class="name">

                        <?php echo e($w[date('w', strtotime($class->start))]); ?>


                         </span>

                </div>
                <div class="mleft" >

                    <div class="right">
                        <div class="pic">
                            <img src="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>" alt="">
                        </div>
                        <div class="det">
                            <div class="job"><span>استاد</span></div>
                            <h4> <?php echo e($teacher->name); ?></h4>
                            <div class="date"><i class="icon-time-line"></i><span>زمان</span> <span>
                                   <?php echo e($w[date('w', strtotime($class->start))]); ?>

                                    <?php echo e(($v->day)); ?>

                                    <?php echo e(($m[$v->month-1])); ?>

                                    <?php echo e(($v->hour.':'. $min )); ?>

                                </span></div>
                        </div>
                    </div>
                    <div class="left" <?php echo e((\Illuminate\Support\Carbon::now()->gt(\Carbon\Carbon::parse($class->start)))?'hidden':''); ?>>
                        <div class="enter-class">
                            <a target="_blank" class="bl" href="<?php echo e(route('home.go.class',[$class->id])); ?>">
                                <span>ورود به کلاس</span>
                            </a>
                        </div>
                        <div class="class-option">
                            <span class="title"><i class="icon-dots"></i>گزینه ها</span>
                            <ul>
                                <li data-id="<?php echo e($class->id); ?>" data-img="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>"  data-name="<?php echo e($teacher->name); ?>"
                                    data-date="
                                             <?php echo e($w[date('w', strtotime($class->start)) ]); ?>

                                    <?php echo e(($v->day)); ?>

                                    <?php echo e(($m[$v->month-1])); ?>

                                    <?php echo e(($v->hour.':'.$min)); ?>

                                        " class="change_class"> <span><i class="icon-write"></i>  ویرایش کلاس</span></li>
                                <li data-id="<?php echo e($class->id); ?>" data-img="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>"  data-name="<?php echo e($teacher->name); ?>"
                                    data-date="
                                             <?php echo e($w[date('w', strtotime($class->start)) ]); ?>

                                    <?php echo e(($v->day)); ?>

                                    <?php echo e(($m[$v->month-1])); ?>

                                    <?php echo e(($v->hour.':'.$min)); ?>

                                        " class="cancel_class"> <span><i class="icon-trash"></i>لغو کلاس</span></li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php echo e($classes->appends(request()->all())->links('home.section.pagination')); ?>



        </div>
    </div>

    <div class="stat-list">
        <div class="row">

            <div class="col-lg-4 col-md-12">
                <div>
                    <div class="singl-statis shade">
                        <div class="top">
                            <div class="numner green">
                                <span>150</span>
                            </div>
                            <div class="det">
                                <span class="title">کلاس های برگزارشده</span>
                                <span class="titleen">Classes held</span>
                            </div>
                            <div class="dot3">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>

                        <div class="bar">
                            <span style="width: 45%;"></span>
                        </div>





                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <div>
                    <div class="singl-statis shade">
                        <div class="top">
                            <div class="numner blue">
                                <span><?php echo e($classes->count()); ?></span>
                            </div>
                            <div class="det">
                                <span class="title">کلاس پیش رو</span>
                                <span class="titleen">Classes ahead</span>
                            </div>
                            <div class="dot3">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>

                        <div class="bar">
                            <span style="width: 57%"></span>
                        </div>





                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <div>
                    <div class="singl-statis shade">
                        <div class="top">
                            <div class="numner orange">
                                <span><?php echo e($user->unreserved_class()); ?></span>
                            </div>
                            <div class="det">
                                <span class="title">کلاس رزرو نشده</span>
                                <span class="titleen">Unreserved classes</span>
                            </div>
                            <div class="dot3">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>

                        <div class="bar">
                            <span style="width: 70%"></span>
                        </div>





                    </div>
                </div>
            </div>

        </div>
    </div>

    <div class="teacher-bot">
        <div class="row">
            <div class="col-lg-4 col-md-12">
                <div>
                    <div class="activate-profile shade">

                        <div class="pic">
                            <img src="images/profile.svg" alt="" class="bg">
                            <img src="images/person3.jpg" alt="" class="pro">
                        </div>

                        <div class="percent">
                            <spna class="num">70</spna>
                            <span> درصد تکمیل شده</span>
                        </div>

                        <div class="profilbut">
                            <div class="lable-container">
                                <input type="checkbox" name="activeprofile" id="activeprofile" value="activeprofile">
                                <label for="activeprofile">
                                    <div class="right">

                                        <span>فعال سازی پروفایل</span>
                                    </div>
                                    <div class="left">
                                        <div class="toggle">
                                            <span></span>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <div class="profile-link">
                            <a href="#">مشاهده پروفایل</a>
                        </div>

                        <div class="process">
                            <p>برای فعال سازی پروفایلتان در تیچر پرو این مراحل را انجام دهید :</p>
                            <ul>

                                <li>
                                    <div class="right">
														<span class="green">
															<i class="icon-discount"></i>
														</span>
                                    </div>
                                    <div class="left">
                                        <span class="title">تعیین قیمت جلسات</span>
                                        <span class="stat green">تکمیل شده<i class="icon-tick2"></i></span>
                                    </div>
                                </li>

                                <li>
                                    <div class="right">
														<span class="blue">
															<i class="icon-calender"></i>
														</span>
                                    </div>
                                    <div class="left">
                                        <span class="title">تعیین برنامه زمانی</span>
                                        <span class="stat green">تکمیل شده<i class="icon-tick2"></i></span>
                                    </div>
                                </li>

                                <li>
                                    <div class="right">
														<span class="orange">
															<i class="icon-pic"></i>
														</span>
                                    </div>
                                    <div class="left">
                                        <span class="title">آپلود تصویر پروفایل</span>
                                        <span class="stat orange">در انتظار انجام<i class=" icon-wait"></i></span>
                                    </div>
                                </li>

                            </ul>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-12">
                <div>

                    <div class="linkbox shade">
                        <div class="button">
                            <a href="#" class="green"><i class="icon-movie"></i><span>مشاهده آموزش</span></a>
                        </div>

                        <div class="right">
                            <div class="pic">
                                <img src="images/team_presentation_two_color.png" alt="">
                            </div>
                            <div class="left">
                                <h4>ویدئو آموزشی نحوه کار با محیط کلاس</h4>
                                <span>اخبار، اطلاع رسانی و آموزش های حرفه ای</span>
                            </div>
                        </div>
                    </div>

                    <div class="linkbox shade">
                        <div class="button">
                            <a href="#" class="blue"><i class="icon-telegram"></i><span>عضویت در کانال</span></a>
                        </div>

                        <div class="right">
                            <div class="pic">
                                <img src="images/new_message.png" alt="">
                            </div>
                            <div class="left">
                                <h4>کانال اطلاع رسانی اساتید</h4>
                                <span>اخبار، اطلاع رسانی و آموزش های حرفه ای</span>
                            </div>
                        </div>
                    </div>

                    <div class="make-class-banner shade">
                        <div class="right">
                            <h3>کلاس حضوریت رو آنلاین و <br>رایگان برگزار کن</h3>
                            <p>!حتی اگر پروفایل شما غیرفعال است</p>
                            <span class="hshtag"># همه_کنار_هم</span>
                            <a href="#">ایجاد کلاس</a>
                        </div>
                        <div class="left">
                            <img src="images/online_presentation_two_color.png" alt="">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="teacher-diagrams">
        <div class="row">

            <div class="col-lg-3 col-md-12">
                <div>

                    <div class="teacher-stat shade">

                        <div class="widget-title">
                            <h3>آمار</h3>

                            <div class="dot3">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>
                        <div class="widget-content">

                            <div class="statbox">
                                <div class="icon">
                                    <span><i class="icon-eye"></i></span>
                                </div>
                                <div class="title">
                                    <span>تعداد بازدید از پروفایل</span>
                                </div>
                                <div class="stat">
                                    <span>54</span>
                                </div>
                            </div>

                            <div class="statbox">
                                <div class="icon">
                                    <span><i class="icon-hearto"></i></span>
                                </div>
                                <div class="title">
                                    <span>تعداد علاقه مندی</span>
                                </div>
                                <div class="stat">
                                    <span>55</span>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <div class="col-lg-9 col-md-12">
                <div>


                    <div class="teacher-stat shade">

                        <div class="widget-title">
                            <h3>نمودار درامد</h3>
                            <div class="diag-filter">
                                <select name="" id="">
                                    <option value="">سال جاری</option>
                                    <option value="">سال قبل</option>
                                </select>
                            </div>
                            <div class="dot3">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>
                        <div class="widget-content">
                            <div class="exp"><p><i class="icon-checkout"></i> <span>درامد این سال  :</span><span>‏44,521,454</span> <span>تومان</span></p></div>
                            <script>
                                window.onload = function () {

                                    var options = {
                                        series: [{
                                            name: "درآمد",
                                            data: [10, 41, 35, 71, 49, 62, 69, 91, 48]
                                        }],
                                        chart: {
                                            height: 350,
                                            type: 'area',
                                            zoom: {
                                                enabled: false
                                            }
                                        },
                                        colors:['#17b687', '#E91E63', '#9C27B0'],
                                        fill: {
                                            colors: ['#17b687', '#E91E63', '#9C27B0'],
                                            type: 'gradient',
                                            gradient: {
                                                shadeIntensity: 1,
                                                inverseColors: false,
                                                opacityFrom: 0.5,
                                                opacityTo: 0,
                                                stops: [0, 90, 100]
                                            },
                                        },
                                        dataLabels: {
                                            enabled: false
                                        },
                                        stroke: {
                                            curve: 'straight'
                                        },
                                        markers: {
                                            size: 8,
                                            colors: ["#fff"],
                                            strokeColors: "#0eb582",
                                            strokeWidth: 4,
                                            hover: {
                                                size: 8,
                                                strokeWidth: 4,
                                                colors: ["#0eb582"],
                                                strokeColors: "#fff",
                                            }
                                        },
                                        title: {
                                            align: 'left'
                                        },
                                        grid: {
                                            row: {
                                                colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
                                                opacity: 0.5
                                            },
                                        },
                                        xaxis: {
                                            categories: ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر'],
                                        }
                                    };

                                    var chart = new ApexCharts(document.querySelector("#chartContainer"), options);
                                    chart.render();

                                }
                            </script>
                            <div id="chartContainer" style=""></div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

    <div class="teacher-diagrams">
        <div class="row">

            <div class="col-lg-7 col-md-12">
                <div>

                    <div class="teacher-comment shade">

                        <div class="widget-title">
                            <h3>آخرین دیدگاه ها</h3>

                            <div class="dot3">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>
                        <div class="widget-content">
                            <div>

                                <div class="ho-comment">
                                    <div class="right">
                                        <img src="images/person5.jpg" alt="">
                                    </div>

                                    <div class="mtexct">
                                        <div class="right">
                                            <div class="name"><span>توسط : یلدا شیرازی</span></div>
                                            <div class="date"><span>3:10 PM جمعه - ۲۳ خرداد ۱۳۹۹</span></div>
                                            <div class="text">
                                                <p>سلام، این یک نوشته یک دیدگاه است. سلام، این یک نوشته یک دیدگاه است.  سلام، این یک نوشته یک دیدگاه است. </p>
                                            </div>
                                        </div>
                                        <div class="buuton">
                                            <span class="remove">حذف<i class="icon-trash"></i></span>
                                            <span class="reply">پاسخ<i class="icon-reply"></i></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="ho-comment">
                                    <div class="right">
                                        <img src="images/person5.jpg" alt="">
                                    </div>

                                    <div class="mtexct">
                                        <div class="right">
                                            <div class="name"><span>توسط : یلدا شیرازی</span></div>
                                            <div class="date"><span>3:10 PM جمعه - ۲۳ خرداد ۱۳۹۹</span></div>
                                            <div class="text">
                                                <p>سلام، این یک نوشته یک دیدگاه است. سلام، این یک نوشته یک دیدگاه است.  سلام، این یک نوشته یک دیدگاه است. </p>
                                            </div>
                                        </div>
                                        <div class="buuton">
                                            <span class="remove">حذف<i class="icon-trash"></i></span>
                                            <span class="reply">پاسخ<i class="icon-reply"></i></span>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="more-comment">
                                <a href="#">مشاهده همه نظرات</a>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <div class="col-lg-5 col-md-12">
                <div>


                    <div class="teacher-cform shade">

                        <div class="widget-title">
                            <h3>پیشنویس سریع مقاله </h3>

                            <div class="dot3">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </div>

                        <div class="widget-content">
                            <form action="">

                                <div class="input-container">
                                    <label for="">عنوان مقاله</label>
                                    <input type="text" placeholder="">
                                </div>

                                <div class="input-container">
                                    <label for="">چه چیزی در ذهن دارید</label>
                                    <textarea name="" id="" cols="30" rows="10"></textarea>
                                </div>

                                <div class="button-container">
                                    <a href="#">رفتن به بخش مقالات</a>
                                    <span class="butt">ذخیره پیشنویس</span>
                                </div>
                            </form>
                        </div>

                    </div>

                </div>
            </div>

        </div>
    </div>


</div>


<div class="popupc" id="reason_change_class_popup">
    <div>
        <div>
            <div>

                <div class="popup-container mini shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>

                    <div class="chclass-pop">
                        <div class="top">

                            <h3>
                                دلیل تغییر زمان را بنویسید
                            </h3>


                        </div>
                        <div class="form">
                            <div class="input-container fill">
                                <label for="">این پیام توسط زمان آموز خوانده میشود</label>
                                <form id="form_change" action="<?php echo e(route('student.change')); ?>"  method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <input type="text" hidden name="meet" id="meet_change">
                                <textarea name="reason" id="reason" cols="30" rows="10"></textarea>
                                </form>
                            </div>
                        </div>
                        <div class="foot">
                            <ul>
                                <li>
                                    <div class="button-container reight border">
                                        <span class="butt close_popup">خیر</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="button-container reight">
                                        <span class="butt" id="do_change">تغییر زمان</span>
                                    </div>
                                </li>
                            </ul>
                        </div>

                    </div>


                </div>

            </div>
        </div>
    </div>
</div>



<div class="popupc" id="change_class_popup">
    <div>
        <div>
            <div>

                <div class="popup-container mini shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>

                    <div class="chclass-pop">
                        <div class="top">

                            <h3>
                                آیا از تغییر زمان کلاس مطمئن هستید؟
                            </h3>
                            <p>
                                اگر بله، ضمن هماهنگی با زمان آموز خود، زمان توافق شده را از روی تقویم فقط در روز جاری انتخاب و  تایید نمایید
                            </p>

                        </div>
                        <div class="bot">
                            <div class="right">
                                <img src="/home/images/trash.png" alt="">
                            </div>
                            <div class="left">
                                <span class="day s_name">نسیم کد خدایان</span>
                                <span class="hour s_date">چهار شنبه 07 خرداد 12:00:00</span>
                            </div>
                        </div>
                        <div class="foot">
                            <ul>
                                <li>
                                    <div class="button-container reight border">
                                        <span class="butt close_popup" id="change_no">خیر</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="button-container reight">
                                        <span class="butt" id="change_yes">تغییر زمان</span>
                                    </div>
                                </li>
                            </ul>
                        </div>

                    </div>


                </div>

            </div>
        </div>
    </div>
</div>


<div class="popupc" id="s_cancel_class_popup">
    <div>
        <div>
            <div>

                <div class="popup-container mini shade">
						<span class="close close_popup">
							<i class="icon-cancel"></i>
						</span>

                    <div class="chclass-pop">
                        <div class="top">

                            <h3>
                                آیا قصد لغو کلاس را دارید ؟
                            </h3>
                            <p>
                                با توجه به نزدیک بودن به زمان کلاس در صورت لغو،20 درصد مبلغ این کلاس از کیف پول شما در تیچر پرو به کیف پول زبان آموزتان منتقل خواهد شد
                            </p>

                        </div>
                        <div class="bot">
                            <div class="right">
                                <img class=" " src="/home/images/trash.png" alt="">
                            </div>
                            <div class="left">
                                <span  class="day s_name">نسیم کد خدایان</span>
                                <span class="hour s_date">چهار شنبه 07 خرداد 12:00:00</span>
                            </div>
                        </div>
                        <div class="foot">
                            <ul>
                                <li>
                                    <div class="button-container close_popup reight border">
                                        <span id="s_cancel_yes" class="butt">خیر</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="button-container  red reight" style="background: #fff!important;">
                                        <form id="cancel_form" action="<?php echo e(route('home.cancel.class')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('post'); ?>
                                            <input id="can_id" type="text" hidden name="class" value="">
                                            <input class="butt " type="submit" value="لغو کلاس">
                                        </form>

                                    </div>
                                </li>
                            </ul>
                        </div>

                    </div>


                </div>

            </div>
        </div>
    </div>
</div>


    <?php if (isset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3)): ?>
<?php $component = $__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3; ?>
<?php unset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/student/profile/dashboard.blade.php ENDPATH**/ ?>
