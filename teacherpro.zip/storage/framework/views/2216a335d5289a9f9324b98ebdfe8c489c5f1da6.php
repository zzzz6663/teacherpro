<?php $__env->startSection('main_body'); ?>





    <div id="maincontent" class="rows sfix">
        <div>





                <div class="profile-settings shade">



                    <ul class="tab-container">
                        <li class="active">

                            <div class="profile-setting">

                                <br>
                                <br>
                                <br>
                                <div class="row">
                                    <div class="col-lg-6 col-md-10 col-sm-12 center-block">
                                        <div>
                                            <div class="profile-form">
                                                <?php if($errors->any()): ?>
                                              <div class="e_section" id="e_section">
                                                      <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                              </div>
                                                <?php endif; ?>
                                                <form action="<?php echo e(route('home.teacher.register')); ?>" method="post" >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('post'); ?>

                                                    <div class="input-container fill">
                                                        <label for="">نام و نام خانوادگی</label>
                                                        <i class="icon-user"></i>
                                                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="‏Erfan Amade">

                                                    </div>

                                                    <div class="input-container fill">
                                                        <label for="">نام کاربری</label>
                                                        <input type="text" name="username" value="<?php echo e(old('username')); ?>" placeholder="‏cQXHR">
                                                    </div>

                                                    <div class="input-container fill">
                                                        <label for="">ایمیل</label>
                                                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="‏erfanamade@gmail.com">
                                                    </div>

                                                    <div class="input-container fill">
                                                        <label for="">شماره موبایل</label>
                                                        <input type="number" name="mobile" value="<?php echo e(old('mobile')); ?>" placeholder="‏09140252498">
                                                    </div>

                                                    <div class="sex">
                                                        <div class="label"> انتخاب جنسیت</div>
                                                        <ul>
                                                            <li>
                                                                <div class="lable-container">
                                                                    <input type="radio" name="sex" <?php echo e((old('sex'))?'checked':''); ?> id="male" value="male">
                                                                    <label for="male">
                                                                        <div>
                                                                            <span>مرد</span>
                                                                            <i class="icon-male"></i>
                                                                        </div>
                                                                    </label>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="lable-container">
                                                                    <input type="radio" name="sex"  <?php echo e((old('sex'))?'checked':''); ?> id="female" value="female">
                                                                    <label for="female">
                                                                        <div>
                                                                            <span>زن</span>
                                                                            <i class="icon-female"></i>
                                                                        </div>
                                                                    </label>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>

                                                    <div class="input-container fill">
                                                        <label for="">کشور</label>
                                                        <input type="text" name="country" value="<?php echo e(old('country')); ?>" placeholder="‏iran (islamic republic of)">
                                                    </div>









                                                    <div class="input-container fill">
                                                        <label for="">کلمه   جدید</label>
                                                        <i class="icon-lock"></i>
                                                        <input type="text" name="password" value="<?php echo e(old('password')); ?>" placeholder="‏">
                                                    </div>

                                                    <div class="input-container fill">
                                                        <label for="">تکرار کلمه عبور</label>
                                                        <i class="icon-lock"></i>
                                                        <input type="text" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="‏">
                                                    </div>

                                                    <div class="button-container reight full">
                                                        <button class="butt">ذخیره تغییرات</button>
                                                    </div>

                                                </form>

                                            </div>


































                                        </div>
                                    </div>
                                </div>
                            </div>



                        </li>

                    </ul>

                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher_register_form.blade.php ENDPATH**/ ?>