<div id="sideteachernav">

    <div class="teacher-prfile">
        <div class="pic">
            <span class="percent"> ۷ss۰%</span>
            <img class="bg" src="/home/images/profile.svg" alt="">

        <?php if(auth()->user()->attr('avatar')): ?>
                <img  class="pro"  src="<?php echo e(asset('src/avatar/'.auth()->user()->attr('avatar'))); ?>" alt="">
            <?php else: ?>
                <img class="pro" src="/src/avatar/<?php echo e((auth()->user()->sex=='male')?'avatar_man.png':'avatar_woman.png'); ?>" alt="">
            <?php endif; ?>
            <i class="icon-info"></i>
        </div>
        <div class="name">
            <?php echo e(auth()->user()->name); ?>

        </div>
        <div class="email"> <?php echo e(auth()->user()->email); ?>   </div>
    </div>

    <div class="pishkhan-nav">
        <ul>
            <li class="<?php echo e(((Route::currentRouteName()=='student.dashboard')?'active':'')); ?>"><a href="<?php echo e(route('student.dashboard')); ?>"><i class="icon-dashboard"></i><span>پیشخوان</span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='student.wallet')?'active':'')); ?>"><a href="<?php echo e(route('student.wallet')); ?>"><i class="icon-dwallet"></i><span>کیف پول</span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='student.profile')?'active':'')); ?>"><a href="<?php echo e(route('student.profile')); ?>"><i class="icon-dwallet"></i><span> حساب کاربری  </span></a></li>
            <li class="<?php echo e(((Route::currentRouteName()=='student.fave')?'active':'')); ?>"><a href="<?php echo e(route('student.fave')); ?>"><i class="icon-dwallet"></i><span>   علاقه مندی ها  </span></a></li>
        </ul>
    </div>

</div>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/student/sidebar.blade.php ENDPATH**/ ?>