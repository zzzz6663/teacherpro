<?php if($paginator->lastPage() > 1): ?>


    <ul class="pagination justify-content-center">

        <li><a href="<?php echo e($paginator->url($paginator->currentPage()+1)); ?>"><i class="icon2-right-big"></i></a></li>

        <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
            <li  class="<?php echo e(($paginator->currentPage() == $i) ? ' active' : ' '); ?>">
                <a  class="<?php echo e(($paginator->currentPage() == $i) ? ' active' : 'page-link'); ?>" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            </li>
        <?php endfor; ?>
        <li><a  href="<?php echo e($paginator->url($paginator->currentPage()-1)); ?>"><i class="icon2-left-big"></i></a></li>
    </ul>


<?php endif; ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/section/pagination2.blade.php ENDPATH**/ ?>