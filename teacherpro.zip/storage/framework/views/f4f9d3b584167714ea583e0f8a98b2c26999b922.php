                <?php $__env->startSection('main_body'); ?>


                    <div id="topheader" class="rows">
                        <div class="container">
                            <div>
                                <?php ($v=verta($article->created_at)); ?>
                                <h1> <?php echo e($article->title); ?></h1>
                                <div class="top-icons">
                                    <ul>
                                        <li>
                                            <a href="#">
								<span class="icon">
									<i class="icon2-user-circle-o"></i>
								</span>
                                                <span class="author">
									<span>از</span> <?php echo e($article->user->name); ?>

								</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
								<span class="icon">
									<i class="icon2-calendar-empty"></i>
								</span>
                                                <span class="date"><?php echo e($v->format('%B %d، %Y')); ?></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
								<span class="icon">
									<i class="icon2-commenting-o"></i>
								</span>
                                                <span class="comments"> <?php echo e($article->comments()->count()); ?> نظر </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="page" class="rows">
                        <div class="container">
                            <div class="tablc">
                                <div class="tabler">

                                    <div id="main">
                                        <div>
                                            <div id="post-text">
                                                <div class="main-pic">
                                                    <img src="<?php echo e(asset('/src/article/images/a1'.$article->image)); ?>" alt="">
                                                </div>
                                              <div class="text">
                                                  <?php echo $article->article; ?>

                                              </div>
                                            </div>

                                            <div id="comments" class="blog-post-comment">
                                                <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                                                    <div id="respond" class="comment-respond">

                                                        <h3 id="reply-title" class="comment-reply-title">ارسال پاسخ
                                                        </h3>
                                                        <?php if($errors->any()): ?>
                                                            <div class="e_section" id="e_section">
                                                                <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                                            </div>
                                                        <?php endif; ?>
                                                        <form id="commentform" class="comment-form"  action="<?php echo e(route('home.comment.article', $article->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('post'); ?>
                                                            <p class="comment-notes">
                                                                <span id="email-notes">نشانی ایمیل شما منتشر نخواهد شد.</span>
                                                                بخش‌های موردنیاز علامت‌گذاری شده‌اند
                                                                <span class="required">*</span>
                                                            </p>

                                                            <div class="comment-info row">
                                                                <div class="col-lg-6 col-md-12">
                                                                    <div>

                                                                        <input placeholder="نام را وارد کنید" id="author" readonly class="form-control" name="author" type="text" value="<?php echo e($article->user->name); ?>" size="30" aria-required="true">
                                                                        <input type="text" id="paretn" value="0" hidden name="parent_id">
                                                                    </div>
                                                                </div>
                                                                <div class="col-lg-6 col-md-12">
                                                                    <div>
                                                                        <input placeholder="ایمیل را وارد کنید" id="email" readonly name="email" class="form-control" type="email" value="<?php echo e($article->user->email); ?>" size="30" aria-required="true">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-lg-12 ">
                                                                    <div>
                                                                        <textarea class="form-control msg-box" placeholder="نظرات را وارد کنید" id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <p class="form-submit">

                                                                <input name="submit" type="submit" id="submit" class="btn-comments btn btn-primary" value="ارسال نظر">
                                                            </p>
                                                        </form>
                                                    </div>
                                                <?php else: ?>
                                                    <p class="form-submit">
                                                         <input name="submit" type="submit" id="submit" class="btn-comments pointer btn btn-primary show_login" value="ارسال نظر">
                                                    </p>
                                                <?php endif; ?>


                                                <div class="bord">


                                                    <div class="btitle">
                                                        <h3 class="comment-reply-title"> <?php echo e($article->comments()->count()); ?> نظر</h3>
                                                    </div>

                                                 <?php echo $__env->make('home.section.comment',['comments'=>$article->comments()->where('parent_id','0')->get()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="sidebar">
                                        <div>



                                            <div class="social">
                                                <a target="_blank">
                                                    <i class="icon2-facebook-squared"></i>
                                                </a>
                                                <a target="_blank">
                                                    <i class="icon2-instagram"></i>
                                                </a>
                                                <a target="_blank">
                                                    <i class="icon2-twitter"></i>
                                                </a>
                                                <a target="_blank">
                                                    <i class="icon2-linkedin"></i>
                                                </a>
                                            </div>







                                        <?php echo $__env->make('home.section.side_article', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                            <h2 class="side-title">برچسب‌ها</h2>

                                            <div class="tag-widgte">
                                                <ul>

                                                    <li>
										<span class="link">
											<span>
                                                	<?php for($i=0;$i<sizeof($tags); $i++): ?>

                                                    <a href="<?php echo e(route('home.tag.articles',$tags[$i])); ?>"><?php echo e($tags[$i]); ?></a>

                                                <?php endfor; ?>
											</span>
										</span>
                                                    </li>
                                                </ul>
                                            </div>


                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="container">
                            <div class="post-nav">

                                    <?php if($prv): ?>
                                <div class="navigation__prev">
                                    <a href="<?php echo e(route('home.single.article',$prv->id)); ?>">

						<span class="arrow-prev">
							<i class="icon2-right-big"></i>
						</span>
                                        <span class="navigation__link__prev">
							<span class="label">Previous</span>
							<span class="title"> <?php echo e($prv->title); ?></span>
						</span>
                                    </a>
                                </div>
                                <?php endif; ?>


                                    <?php if($next): ?>
                                <div class="navigation__next">
                                    <a href="<?php echo e(route('home.single.article',$next->id)); ?>">
						<span class="arrow-next">
							<i class="icon2-left-big"></i>
						</span>
                                        <span class="navigation__link__next">
							<span class="label">Next</span>
							<span class="title">  <?php echo e($next->title); ?></span>
						</span>

                                    </a>
                                </div>
                                        <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="rows">
                        <div class="container">
                            <div class="post-newsletter">
                                <div>
                                    <p>برای آگاهی از آخرین اخبار مربوط به زبان</p>
                                    <p class="green">عضو خبرنامه آکادمی زبان تهران شوید</p>
                                    <form>

                                        <div>
                                            <div class="type-email">
                                                <input size="1" type="email" class="email" placeholder="ایمیل خود را وارد کنید" required="required" aria-required="true">
                                            </div>
                                            <div class="type-submit">
                                                <button type="submit">
									<span>
										<span class="elementor-button-text">عضویت</span>

										<span class="button-icon">
											<i aria-hidden="true" class="icon2-left-big"></i>
										</span>
									</span>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="related-post" class="rows">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div>
                                        <h4 class="green">مطالب مربوطه</h4>
                                        <h4 class="black">More To Explore</h4>
                                    </div>
                                </div>
                            </div>


                            <div class="row">
                                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $re): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php ($v=verta($re->created_at)); ?>
                                <div class="col-lg-4 col-sm-6 col-xsm-12">
                                    <div>
                                        <div class="single-post">

                                            <div class="elementor-post__card">
                                                <a class="elementor-post__thumbnail__link" href="#">
                                                    <div class="elementor-post__thumbnail elementor-fit-height">
                                                        <img src="/home/images/blog1.jpg" alt="">

                                                    </div>
                                                </a>
                                                <div class="elementor-post__badge"><?php echo e($re->acats()->first()->name); ?></div>
                                                <div class="elementor-post__text">
                                                    <h3 class="elementor-post__title">
                                                        <a href="<?php echo e(route('home.single.article',$re->id)); ?>"> <?php echo e($re->title); ?> </a>
                                                    </h3>
                                                    <div class="elementor-post__excerpt" style="text-align: right">

                                                            <?php echo $re->article; ?>

                                                    </div>
                                                </div>
                                                <div class="elementor-post__meta-data">
                                                    <span class="elementor-post-author"> <?php echo e($re->user->name); ?> </span>
                                                    <span class="elementor-post-date"><?php echo e($v->format('%B %d، %Y')); ?></span>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>



                <?php $__env->stopSection(); ?>








<?php echo $__env->make('master.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\teacherpro\resources\views/home/single_article.blade.php ENDPATH**/ ?>