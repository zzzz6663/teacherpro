
<div id="search">

    <form action="<?php echo e(route('home.articles')); ?>" method="get">
        <?php echo csrf_field(); ?>
        <?php echo method_field('fet'); ?>
        <div>
            <input placeholder="جستجو..." type="search" name="search" title="جستجو" value="<?php echo e(request('search')); ?>">
            <button> <i class="icon2-search" aria-hidden="true"></i>
            </button>
        </div>
    </form>

</div>

<h2 class="side-title">دسته‌بندی‌ها</h2>



<div class="sidebar-nav">
    <ul class="metismenu" id="menu1">

        <?php $__currentLoopData = \App\Models\Acat::whereNull('parent_id')->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(\App\Models\Acat::where('parent_id',$ac->id)->latest()->get()->first()  ): ?>
                <li  >
                    <a class="has-arrow bl"   aria-expanded="false"><?php echo e($ac->name); ?></a>
                    <ul class="mm-collapse">
                        <?php $__currentLoopData = \App\Models\Acat::where('parent_id',$ac->id)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a  href="<?php echo e(route('home.articles',$accc->id)); ?>"  class="bl"> <?php echo e($accc->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            <?php else: ?>
                <li>
                    <a   href="<?php echo e(route('home.articles',$ac->id)); ?>" class="bl">
                        <?php echo e($ac->name); ?>

                    </a>
                </li>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </ul>
</div>



<h2 class="side-title">مطالب اخیر</h2>
<?php $__currentLoopData = \App\Models\Article::where('submit','1')->where('active','1')->take(4)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="side-blog">
        <a class="elementor-post__thumbnail__link" href="#">
            <div class="elementor-post__thumbnail">
                <img src="<?php echo e(asset('/src/article/images/a2'.$latest->image)); ?>" alt="">
            </div>
        </a>
        <div class="elementor-post__text">
            <h3 class="elementor-post__title">
                <a href="<?php echo e(route('home.single.article',$latest->id)); ?>"><?php echo e($latest->title); ?> </a>
            </h3>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/section/side_article.blade.php ENDPATH**/ ?>