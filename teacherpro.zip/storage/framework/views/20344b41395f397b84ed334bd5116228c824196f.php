<?php $__env->startComponent('home.teacher.content',['title'=>' تنظیمات  ']); ?>


<div id="teacherpish">

    <?php $__env->slot('bread'); ?>

        <?php echo $__env->make('home.teacher.profile.bread_left',['name'=>'حساب  کاربری'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->endSlot(); ?>




</div>

<div class="profile-settings shade">
    <div class="dot3">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <ul class="tab-nav" id="jtab">
        <li class="taby active"   ><span>پروفایل</span></li>
        <li class="taby" ><span>حوضه تخصص</span></li>
        <li class="taby" ><span>رزومه</span></li>
        <li class="taby" ><span>آپلود ویدیو</span></li>
        <li class="taby" ><span>رمز عبور</span></li>
    </ul>



    <ul class="tab-container tabv">
        <li class="active tabv">

            <div class="profile-setting">
                <div class="cover">

                    <?php if(file_exists(public_path('/src/bg/'.$user->attr('bg'))) && !empty($user->attr('bg'))): ?>
                        <img src="<?php echo e(asset('src/bg/'.$user->attr('bg'))); ?>" alt="">

                    <?php else: ?>
                        <img src="/home/images/cover.png" alt="">
                    <?php endif; ?>
                    <form action="<?php echo e(route('teacher.save.bg',$user->id)); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="lable-container">
                            <input id="cover-file" type="file">
                            <input id="profile-files" name="bg" class="avat2" type="file" accept="image/*">
                            <label for="cover-file">
                                <i class="icon-info"></i>
                                <span>کاورپروفایل</span>
                            </label>
                        </div>
                    </form>

                </div>

                <div class="profile-pic">
                    <?php if(file_exists(public_path('/src/avatar/'.$user->attr('avatar')))): ?>
                        <img src="<?php echo e(asset('src/avatar/'.$user->attr('avatar'))); ?>" alt="">
                    <?php else: ?>
                        <img src="/src/avatar/<?php echo e(($user->sex=='male')?'avatar_man.png':'avatar_woman.png'); ?>" alt="">
                    <?php endif; ?>

                    <form action="<?php echo e(route('teacher.save.avatar',$user->id)); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="lable-container">
                            <input id="profile-file" name="avatar" class="avat" type="file" accept="image/*">
                            <label for="profile-file">
                                <i class="icon-info"></i>
                            </label>
                        </div>
                    </form>
                </div>

                <div class="row">
                    <div class="col-lg-12 col-md-10 col-sm-12 center-block">
                        <div>
                            <div class="profile-form">



                                    <?php if($errors->any()): ?>
                                        <div class="e_section" id="e_section">
                                            <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                        </div>
                                    <?php endif; ?>


                                    <form id="info" action="<?php echo e(route('teacher.profile.save.info',$user->id)); ?>" class=" " method="post"  >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>

                                    <div class="input-container fill">
                                        <label for="">نام و نام خانوادگی</label>
                                        <i class="icon-user"></i>
                                        <input name="name" type="text" value="<?php echo e(old('name',$user->name)); ?>"  placeholder="‏Erfan Amade">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">نام کاربری</label>
                                        <input name="username" type="text" readonly value="<?php echo e(old('username',$user->username)); ?>"  placeholder="‏cQXHR">
                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">ایمیل</label>
                                        <input name="email" type="email" value="<?php echo e(old('email',$user->email)); ?>"  placeholder="‏erfanamade@gmail.com">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">شماره موبایل</label>
                                        <input name="mobile" type="number" value="<?php echo e(old('mobile',$user->mobile)); ?>"  placeholder="‏09140252498">
                                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="sex">
                                        <div class="label"> انتخاب جنسیت</div>
                                        <ul>
                                            <li>
                                                <div class="lable-container">
                                                    <input <?php echo e((old('sex',$user->sex)=='male')?'checked':''); ?> type="radio" name="sex" id="male" value="male">
                                                    <label for="male">
                                                        <div>
                                                            <span>مرد</span>
                                                            <i class="icon-male"></i>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="lable-container">
                                                    <input  <?php echo e((old('sex',$user->sex)=='female')?'checked':''); ?>  type="radio" name="sex" id="female" value="female">
                                                    <label for="female">
                                                        <div>
                                                            <span>زن</span>
                                                            <i class="icon-female"></i>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">کشور</label>
                                        <input name="country" type="text" value="<?php echo e(old('country',$user->email)); ?>" placeholder="‏iran (islamic republic of)">
                                        <?php $__errorArgs = ['shaba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">بیوگرافی </label>
                                        <textarea name="bio" id="" cols="30" rows="10" placeholder="‏. خود را به زبان آموزانی که بیوگرافی شما را مشاهده میکنند معرفی کنید	میتوانید مدارک صیلی، تجربیات و همچنین سبک، روش تدریس و سطح زبان مورد 	.آموزشتان را بنویسید"‏><?php echo e(old('sex',$user->bio)); ?></textarea>
                                        <?php $__errorArgs = ['shaba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>



                                    <div class="button-container reight full">
                                        <input type="submit" class="bt" value="ذخیره تغییرات">
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </li>
        <li class=" tabv">

            <div class="expert-form">
                                <form action="<?php echo e(route('teacher.save.expert',$user->id)); ?>" method="post" id="teacher_ab_form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>

                    <div class="expert-section">
                        <h4>سطوح تدریس</h4>
                        <h5> انتخاب سطح</h5>
                        <div class="forsm">
                            <div class="ra row">

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Starter">
                                            <input type="checkbox" <?php echo e(($user->attr('Starter'))?'checked':''); ?> id="Starter" name="Starter">
                                            <label class="key" for="Starter">

                                                <div class="right">
                                                    <span>       Starter</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Elementary">
                                            <input type="checkbox" <?php echo e(($user->attr('Elementary'))?'checked':''); ?> id="Elementary" name="Elementary">
                                            <label class="key" for="Elementary">

                                                <div class="right">
                                                    <span>       Elementary</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Intermediate">
                                            <input type="checkbox" <?php echo e(($user->attr('Intermediate'))?'checked':''); ?> id="Intermediate" name="Intermediate">
                                            <label class="key" for="Intermediate">

                                                <div class="right">
                                                    <span>       Intermediate</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Upper_intermediate">
                                            <input type="checkbox" <?php echo e(($user->attr('Upper_intermediate'))?'checked':''); ?> id="Upper_intermediate" name="Upper_intermediate">
                                            <label class="key" for="Upper_intermediate">

                                                <div class="right">
                                                    <span>       Upper intermediate</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Advanced">
                                            <input type="checkbox" <?php echo e(($user->attr('Advanced'))?'checked':''); ?> id="Advanced" name="Advanced">
                                            <label class="key" for="Advanced">

                                                <div class="right">
                                                    <span>       Advanced</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Mastery">
                                            <input type="checkbox" <?php echo e(($user->attr('Mastery'))?'checked':''); ?> id="Mastery" name="Mastery">
                                            <label class="key" for="Mastery">

                                                <div class="right">
                                                    <span>       Mastery</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>



                    <div class="expert-section">
                        <h4>لهجه مدرس</h4>
                        <h5>افزودن لهجه تدریس</h5>
                        <div class="forsm">
                            <div class="ra row">
                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="American_Accent">
                                            <input type="checkbox" <?php echo e(($user->attr('American_Accent'))?'checked':''); ?> id="American_Accent" name="American_Accent">
                                            <label class="key" for="American_Accent">

                                                <div class="right">
                                                    <span>       American Accent</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="British_Accent">
                                            <input type="checkbox" <?php echo e(($user->attr('British_Accent'))?'checked':''); ?> id="British_Accent" name="British_Accent">
                                            <label class="key" for="British_Accent">

                                                <div class="right">
                                                    <span>       British Accent</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Australian_Accent">
                                            <input type="checkbox" <?php echo e(($user->attr('Australian_Accent'))?'checked':''); ?> id="Australian_Accent" name="Australian_Accent">
                                            <label class="key" for="Australian_Accent">

                                                <div class="right">
                                                    <span>       Australian Accent</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Indian_Accent">
                                            <input type="checkbox" <?php echo e(($user->attr('Indian_Accent'))?'checked':''); ?> id="Indian_Accent" name="Indian_Accent">
                                            <label class="key" for="Indian_Accent">

                                                <div class="right">
                                                    <span>       Indian Accent</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Irish_Accent">
                                            <input type="checkbox" <?php echo e(($user->attr('Irish_Accent'))?'checked':''); ?> id="Irish_Accent" name="Irish_Accent">
                                            <label class="key" for="Irish_Accent">

                                                <div class="right">
                                                    <span>       Irish Accent</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Scottish_Accent">
                                            <input type="checkbox" <?php echo e(($user->attr('Scottish_Accent'))?'checked':''); ?> id="Scottish_Accent" name="Scottish_Accent">
                                            <label class="key" for="Scottish_Accent">

                                                <div class="right">
                                                    <span>       Scottish Accent</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="South_African_Accent">
                                            <input type="checkbox" <?php echo e(($user->attr('South_African_Accent'))?'checked':''); ?> id="South_African_Accent" name="South_African_Accent">
                                            <label class="key" for="South_African_Accent">

                                                <div class="right">
                                                    <span>       South African Accent</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="expert-section">
                        <h4>سن</h4>
                        <h5>افزودن سن تدریس</h5>
                        <div class="forsm">
                            <div class="ra row">
                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Children_">
                                            <input type="checkbox" <?php echo e(($user->attr('Children'))?'checked':''); ?> id="Children_(4-11)" name="Children">
                                            <label class="key" for="Children_(4-11)">

                                                <div class="right">
                                                    <span>       Children (4-11)</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Teenagers_">
                                            <input type="checkbox" <?php echo e(($user->attr('Teenagers'))?'checked':''); ?> id="Teenagers_(12-18)" name="Teenagers">
                                            <label class="key" for="Teenagers_(12-18)">

                                                <div class="right">
                                                    <span>       Teenagers (12-18)</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Adults_">
                                            <input type="checkbox" <?php echo e(($user->attr('Adults'))?'checked':''); ?> id="Adults_(18+)" name="Adults">
                                            <label class="key" for="Adults_(18+)">

                                                <div class="right">
                                                    <span>       Adults (18+)</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="expert-section">
                        <h4>کلاس شامل چه  مواردی میشود</h4>
                        <h5>افزودن موارد</h5>
                        <div class="forsm">
                            <div class="ra row">
                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Curriculum">
                                            <input type="checkbox" <?php echo e(($user->attr('Curriculum'))?'checked':''); ?> id="Curriculum" name="Curriculum">
                                            <label class="key" for="Curriculum">

                                                <div class="right">
                                                    <span>       Curriculum</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Homework">
                                            <input type="checkbox" <?php echo e(($user->attr('Homework'))?'checked':''); ?> id="Homework" name="Homework">
                                            <label class="key" for="Homework">

                                                <div class="right">
                                                    <span>       Homework</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Learning_Materials">
                                            <input type="checkbox" <?php echo e(($user->attr('Learning_Materials'))?'checked':''); ?> id="Learning_Materials" name="Learning_Materials">
                                            <label class="key" for="Learning_Materials">

                                                <div class="right">
                                                    <span>       Learning Materials</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Writing_Exercises">
                                            <input type="checkbox" <?php echo e(($user->attr('Writing_Exercises'))?'checked':''); ?> id="Writing_Exercises" name="Writing_Exercises">
                                            <label class="key" for="Writing_Exercises">

                                                <div class="right">
                                                    <span>       Writing Exercises</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Lesson_Plans">
                                            <input type="checkbox" <?php echo e(($user->attr('Lesson_Plans'))?'checked':''); ?> id="Lesson_Plans" name="Lesson_Plans">
                                            <label class="key" for="Lesson_Plans">

                                                <div class="right">
                                                    <span>       Lesson Plans</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Proficiency_Assessment">
                                            <input type="checkbox" <?php echo e(($user->attr('Proficiency_Assessment'))?'checked':''); ?> id="Proficiency_Assessment" name="Proficiency_Assessment">
                                            <label class="key" for="Proficiency_Assessment">

                                                <div class="right">
                                                    <span>       Proficiency Assessment</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Quizzes_Tests">
                                            <input type="checkbox" <?php echo e(($user->attr('Quizzes_Tests'))?'checked':''); ?> id="Quizzes_Tests" name="Quizzes_Tests">
                                            <label class="key" for="Quizzes_Tests">

                                                <div class="right">
                                                    <span>       Quizzes Tests</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Reading_Exercises">
                                            <input type="checkbox" <?php echo e(($user->attr('Reading_Exercises'))?'checked':''); ?> id="Reading_Exercises" name="Reading_Exercises">
                                            <label class="key" for="Reading_Exercises">

                                                <div class="right">
                                                    <span>       Reading Exercises</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="expert-section">
                        <h4>موضوعات</h4>
                        <h5>افزودن موضوعات</h5>
                        <div class="forsm">
                            <div class="ra row">
                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Business_English">
                                            <input type="checkbox" <?php echo e(($user->attr('Business_English'))?'checked':''); ?> id="Business_English" name="Business_English">
                                            <label class="key" for="Business_English">

                                                <div class="right">
                                                    <span>       Business English</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Interview_Preparation">
                                            <input type="checkbox" <?php echo e(($user->attr('Interview_Preparation'))?'checked':''); ?> id="Interview_Preparation" name="Interview_Preparation">
                                            <label class="key" for="Interview_Preparation">

                                                <div class="right">
                                                    <span>       Interview Preparation</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Reading_Comprehension">
                                            <input type="checkbox" <?php echo e(($user->attr('Reading_Comprehension'))?'checked':''); ?> id="Reading_Comprehension" name="Reading_Comprehension">
                                            <label class="key" for="Reading_Comprehension">

                                                <div class="right">
                                                    <span>       Reading Comprehension</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Listening_Comprehension">
                                            <input type="checkbox" <?php echo e(($user->attr('Listening_Comprehension'))?'checked':''); ?> id="Listening_Comprehension" name="Listening_Comprehension">
                                            <label class="key" for="Listening_Comprehension">

                                                <div class="right">
                                                    <span>       Listening Comprehension</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Speaking_Practice">
                                            <input type="checkbox" <?php echo e(($user->attr('Speaking_Practice'))?'checked':''); ?> id="Speaking_Practice" name="Speaking_Practice">
                                            <label class="key" for="Speaking_Practice">

                                                <div class="right">
                                                    <span>       Speaking Practice</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Writing_Correction">
                                            <input type="checkbox" <?php echo e(($user->attr('Writing_Correction'))?'checked':''); ?> id="Writing_Correction" name="Writing_Correction">
                                            <label class="key" for="Writing_Correction">

                                                <div class="right">
                                                    <span>       Writing Correction</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Vocabulary_Development">
                                            <input type="checkbox" <?php echo e(($user->attr('Vocabulary_Development'))?'checked':''); ?> id="Vocabulary_Development" name="Vocabulary_Development">
                                            <label class="key" for="Vocabulary_Development">

                                                <div class="right">
                                                    <span>       Vocabulary Development</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Grammar_Development">
                                            <input type="checkbox" <?php echo e(($user->attr('Grammar_Development'))?'checked':''); ?> id="Grammar_Development" name="Grammar_Development">
                                            <label class="key" for="Grammar_Development">

                                                <div class="right">
                                                    <span>       Grammar Development</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Academic_English">
                                            <input type="checkbox" <?php echo e(($user->attr('Academic_English'))?'checked':''); ?> id="Academic_English" name="Academic_English">
                                            <label class="key" for="Academic_English">

                                                <div class="right">
                                                    <span>       Academic English</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Accent_Reduction">
                                            <input type="checkbox" <?php echo e(($user->attr('Accent_Reduction'))?'checked':''); ?> id="Accent_Reduction" name="Accent_Reduction">
                                            <label class="key" for="Accent_Reduction">

                                                <div class="right">
                                                    <span>       Accent Reduction</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Phonetics">
                                            <input type="checkbox" <?php echo e(($user->attr('Phonetics'))?'checked':''); ?> id="Phonetics" name="Phonetics">
                                            <label class="key" for="Phonetics">

                                                <div class="right">
                                                    <span>       Phonetics</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Colloquial_English">
                                            <input type="checkbox" <?php echo e(($user->attr('Colloquial_English'))?'checked':''); ?> id="Colloquial_English" name="Colloquial_English">
                                            <label class="key" for="Colloquial_English">

                                                <div class="right">
                                                    <span>       Colloquial English</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 col-md-12">
                                    <div>
                                        <div class="lable-container" style="line-height: 50px">
                                            <input type="text" hidden name="Phonetics">
                                            <input type="checkbox" <?php echo e(($user->attr('Phonetics'))?'checked':''); ?> id="Phonetics" name="Phonetics">
                                            <label class="key" for="Phonetics">

                                                <div class="right">
                                                    <span>       Phonetics</span>
                                                </div>
                                                <div class="left">
                                                    <div class="toggle">
                                                        <span></span>
                                                    </div>
                                                </div>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>






                    <div class="expert-section">
                        <h4>آمادگی برای آزمون</h4>
                        <h5>افزودن آزمون</h5>
                        <div class="forsm">
                            <div class="ra ">
                                <br>
                                <br>
                                <h1>انگلیسی:</h1>

                                <div class="row">


                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="TOEFL">
                                                <input type="checkbox" <?php echo e(($user->attr('TOEFL'))?'checked':''); ?> id="TOEFL" name="TOEFL">
                                                <label class="key" for="TOEFL">

                                                    <div class="right">
                                                        <span>       TOEFL</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="IELTS">
                                                <input type="checkbox" <?php echo e(($user->attr('IELTS'))?'checked':''); ?> id="IELTS" name="IELTS">
                                                <label class="key" for="IELTS">

                                                    <div class="right">
                                                        <span>       IELTS</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="PTE">
                                                <input type="checkbox" <?php echo e(($user->attr('PTE'))?'checked':''); ?> id="PTE" name="PTE">
                                                <label class="key" for="PTE">

                                                    <div class="right">
                                                        <span>       PTE</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="GRE">
                                                <input type="checkbox" <?php echo e(($user->attr('GRE'))?'checked':''); ?> id="GRE" name="GRE">
                                                <label class="key" for="GRE">

                                                    <div class="right">
                                                        <span>       GRE</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="CELPIP">
                                                <input type="checkbox" <?php echo e(($user->attr('CELPIP'))?'checked':''); ?> id="CELPIP" name="CELPIP">
                                                <label class="key" for="CELPIP">

                                                    <div class="right">
                                                        <span>       CELPIP</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="Duolingo">
                                                <input type="checkbox" <?php echo e(($user->attr('Duolingo'))?'checked':''); ?> id="Duolingo" name="Duolingo">
                                                <label class="key" for="Duolingo">

                                                    <div class="right">
                                                        <span>       Duolingo</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="TOEIC">
                                                <input type="checkbox" <?php echo e(($user->attr('TOEIC'))?'checked':''); ?> id="TOEIC" name="TOEIC">
                                                <label class="key" for="TOEIC">

                                                    <div class="right">
                                                        <span>       TOEIC</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="KET">
                                                <input type="checkbox" <?php echo e(($user->attr('KET'))?'checked':''); ?> id="KET" name="KET">
                                                <label class="key" for="KET">

                                                    <div class="right">
                                                        <span>       KET</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="PET">
                                                <input type="checkbox" <?php echo e(($user->attr('PET'))?'checked':''); ?> id="PET" name="PET">
                                                <label class="key" for="PET">

                                                    <div class="right">
                                                        <span>       PET</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="CAE">
                                                <input type="checkbox" <?php echo e(($user->attr('CAE'))?'checked':''); ?> id="CAE" name="CAE">
                                                <label class="key" for="CAE">

                                                    <div class="right">
                                                        <span>       CAE</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="FCE">
                                                <input type="checkbox" <?php echo e(($user->attr('FCE'))?'checked':''); ?> id="FCE" name="FCE">
                                                <label class="key" for="FCE">

                                                    <div class="right">
                                                        <span>       FCE</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="CPE">
                                                <input type="checkbox" <?php echo e(($user->attr('CPE'))?'checked':''); ?> id="CPE" name="CPE">
                                                <label class="key" for="CPE">

                                                    <div class="right">
                                                        <span>       CPE</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="BEC">
                                                <input type="checkbox" <?php echo e(($user->attr('BEC'))?'checked':''); ?> id="BEC" name="BEC">
                                                <label class="key" for="BEC">

                                                    <div class="right">
                                                        <span>       BEC</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="TOEFLPhD">
                                                <input type="checkbox" <?php echo e(($user->attr('TOEFLPhD'))?'checked':''); ?> id="TOEFLPhD" name="TOEFLPhD">

                                                
                                                <label class="key" for="TOEFLPhD">

                                                    <div class="right">
                                                        <span>       TOEFL PhD</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <br>
                                </div>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>
                                <br>


                                <div class="row">
                                    <h1>فرانسه:</h1>
                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="TCF">
                                                <input type="checkbox" <?php echo e(($user->attr('TCF'))?'checked':''); ?> id="TCF" name="TCF">
                                                <label class="key" for="TCF">

                                                    <div class="right">
                                                        <span>       TCF</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="TEF">
                                                <input type="checkbox" <?php echo e(($user->attr('TEF'))?'checked':''); ?> id="TEF" name="TEF">
                                                <label class="key" for="TEF">

                                                    <div class="right">
                                                        <span>       TEF</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="DELF">
                                                <input type="checkbox" <?php echo e(($user->attr('DELF'))?'checked':''); ?> id="DELF" name="DELF">
                                                <label class="key" for="DELF">

                                                    <div class="right">
                                                        <span>       DELF</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="DALF">
                                                <input type="checkbox" <?php echo e(($user->attr('DALF'))?'checked':''); ?> id="DALF" name="DALF">
                                                <label class="key" for="DALF">

                                                    <div class="right">
                                                        <span>       DALF</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <br>
                                </div>
                                <br>
                                <br>
                                <h1>آلمانی:</h1>

                                <div class="row">
                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="Goethe">
                                                <input type="checkbox" <?php echo e(($user->attr('Goethe'))?'checked':''); ?> id="Goethe" name="Goethe">
                                                <label class="key" for="Goethe">

                                                    <div class="right">
                                                        <span>       Goethe</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="Telc">
                                                <input type="checkbox" <?php echo e(($user->attr('Telc'))?'checked':''); ?> id="Telc" name="Telc">
                                                <label class="key" for="Telc">

                                                    <div class="right">
                                                        <span>       Telc</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="Test_Daf">
                                                <input type="checkbox" <?php echo e(($user->attr('Test_Daf'))?'checked':''); ?> id="Test_Daf" name="Test_Daf">
                                                <label class="key" for="Test_Daf">

                                                    <div class="right">
                                                        <span>       Test Daf</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="OSD">
                                                <input type="checkbox" <?php echo e(($user->attr('OSD'))?'checked':''); ?> id="OSD" name="OSD">
                                                <label class="key" for="OSD">

                                                    <div class="right">
                                                        <span>       OSD</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <br>
                                </div>
                                <br>
                                <br>
                                <h1>ترکی استانبولی:</h1>

                                <div class="row">
                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="TOMER">
                                                <input type="checkbox" <?php echo e(($user->attr('TOMER'))?'checked':''); ?> id="TOMER" name="TOMER">
                                                <label class="key" for="TOMER">

                                                    <div class="right">
                                                        <span>       TOMER</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="TYS">
                                                <input type="checkbox" <?php echo e(($user->attr('TYS'))?'checked':''); ?> id="TYS" name="TYS">
                                                <label class="key" for="TYS">

                                                    <div class="right">
                                                        <span>       TYS</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <br>
                                </div>
                                <br>
                                <br>
                                <h1>انگلیسی:</h1>

                                <div class="row">
                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="DELE">
                                                <input type="checkbox" <?php echo e(($user->attr('DELE'))?'checked':''); ?> id="DELE" name="DELE">
                                                <label class="key" for="DELE">

                                                    <div class="right">
                                                        <span>       DELE</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-12">
                                        <div>
                                            <div class="lable-container" style="line-height: 50px">
                                                <input type="text" hidden name="SIELE">
                                                <input type="checkbox" <?php echo e(($user->attr('SIELE'))?'checked':''); ?> id="SIELE" name="SIELE">
                                                <label class="key" for="SIELE">

                                                    <div class="right">
                                                        <span>       SIELE</span>
                                                    </div>
                                                    <div class="left">
                                                        <div class="toggle">
                                                            <span></span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <br>
                                </div>



                            </div>
                        </div>
                    </div>


                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div>
                                                <input type="submit" value="ثبت" class="bt">
                                            </div>
                                        </div>
                                    </div>
                </form>
            </div>
        </li>




































































































































        <li class="tabv">

            <div class="resume-setting">
                <?php $__currentLoopData = $resume; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $re): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="resume-section-edit">
                    <div class="right">
                        <ul>




                            <li class="del-link" >
                                <form id="ff_<?php echo e($re->id); ?>" action="<?php echo e(route('Resume.destroy',$re->id)); ?>" class="delete_user_note" method="post"  >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <span onclick="document.getElementById('ff_<?php echo e($re->id); ?>').submit()">
                                        حذف<i class="icon-trash"></i></span>
                                        
                                        
                                </form>
                            </li>
                            <li class="edit-link" >
                                <form id="dd_<?php echo e($re->id); ?>" action="<?php echo e(route('Resume.edit',$re->id)); ?>" class="delete_user_note" method="get"  >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('get'); ?>
                                    <span onclick="document.getElementById('dd_<?php echo e($re->id); ?>').submit()">
                                        ویرایش<i class="icon-trash"></i></span>
                                    
                                    
                                </form>
                            </li>
                        </ul>
                    </div>
                    <div class="left">
                        <h5><?php echo e(__('arr.'.$re->type)); ?>: <?php echo e($re->place); ?>   </h5>
                        <p><?php echo e($re->title); ?> : <?php echo e($re->info); ?>   </p>
                        <span class="date">
												<span>
                                                <?php echo e($re->from); ?> - <?php echo e($re->till); ?>

                                                </span>
												<i class="icon-time-line"></i>
											</span>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                <div class="addresume">

                    <div class="row">


                        <div class="col-lg-6 col-md-12">
                            <div>
                                <img src="/home/images/mind_map_two_color.png" alt="">
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-12">
                            <div>
                                <?php if($errors->any()): ?>
                                    <div class="e_section" id="e_section">
                                        <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('Resume.store',$user->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>

                                    <div class="label">
                                        <span>انتخاب نوع</span>
                                    </div>

                                    <div class="check-buttonlist">
                                        <ul>
                                            <li>

                                                <div class="lable-container">
                                                    <input type="radio"   name="type" <?php echo e((old('type')=='education')?'checked':""); ?> id="education" value="education">
                                                    <label for="education">
                                                        <div class="right">
                                                            <span>تحصیلی</span>
                                                        </div>
                                                        <div class="left">
                                                            <div class="circle">
                                                                <span></span>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                            <li>

                                                <div class="lable-container">
                                                    <input type="radio" name="type" <?php echo e((old('type')=='sabeghe')?'checked':""); ?> id="sabeghe" value="sabeghe">
                                                    <label for="sabeghe">
                                                        <div class="right">
                                                            <span>سابقه کار</span>
                                                        </div>
                                                        <div class="left">
                                                            <div class="circle">
                                                                <span></span>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="lable-container">
                                                    <input type="radio" name="type" <?php echo e((old('type')=='licence')?'checked':""); ?> id="licence" value="licence">
                                                    <label for="licence">
                                                        <div class="right">
                                                            <span>گواهی‌ها</span>
                                                        </div>
                                                        <div class="left">
                                                            <div class="circle">
                                                                <span></span>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">عنوان</label>
                                        <input type="text" name="title" value="<?php echo e(old('type')); ?>" placeholder="‏">
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">توضیحات</label>
                                        <input type="text" name="info"  value="<?php echo e(old('info')); ?>" placeholder="‏">
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">محل</label>
                                        <input type="text" name="place"  value="<?php echo e(old('place')); ?>" placeholder="‏">
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div>
                                                <div class="input-container fill">
                                                    <label for="from">تاریخ از :</label>
                                                    <select name="from" id="from">
                                                        <option value="">از</option>
                                                      <?php for($i=1340;$i<1401;$i++): ?>
                                                            <option <?php echo e((old('from')==$i)?'selected':''); ?> value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                          <?php endfor; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div>
                                                <div class="input-container fill">
                                                    <label for="till">تاریخ تا :</label>
                                                    <select name="till" id="till">
                                                        <option value="">تا</option>
                                                        <?php for($i=1340;$i<1401;$i++): ?>
                                                            <option <?php echo e((old('till')==$i)?'selected':''); ?> value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="button-container reight">
                                        <input type="submit" class="bt" value="افزودن">
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>


                </div>
            </div>


        </li>
        <li class="tabv">
            <div class="video-setting">

                <div class="upload-section">

                    <?php if($errors->any()): ?>
                        <div class="e_section" id="e_section">
                            <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                        </div>
                    <?php endif; ?>


                    <form id="port_form" action="<?php echo e(route('teacher.save.port',$user->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                    <div class="row">
                        <div class="col-lg-7 col-md-10 col-sm-12 center-block">
                            <div>

                                <div class="featured-pic">
                                    <h4>تصویر شاخص</h4>
                                    <div id="fileuploader">
                                        <label for="featured-pic">عکس ابتدای ویدیو را آپلود کنید</label>
                                        <input type="file" id="featured-pic" accept="image/*" name="port_img">
                                        <br>
                                        <p style="text-align: center" id="img_name"></p>
                                    </div>
                                </div>

                                <div class="featured-video">
                                    <h4>آپلود ویدیوی معرفی <span>با آپلود ویدئو معرفی، فروشتان در تیچر پرو را تا ۹۰٪ افزایش دهید</span></h4>
                                    <div id="fileuploader2" class="draggable">
                                        <div class="vup">

                                            <div class="drag">
                                                <div class="upv"><i class="icon-cloud"></i><span>فایل را بکشید و در اینجا رها کنید</span><span class="or">یا</span></div>
                                            </div>
                                            <input type="file" accept="video/mp4" id="featured-video" name="port_vid">
                                            <label for="featured-video">انتخاب فایل</label>
                                            <br>
                                            <p style="text-align: center" id="vid_name"></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="video-op">
                                    <ul>
                                        <li> حجم ویدئو حداکثر ۲۵ مگابایت باشد</li>
                                        <li>‏MP4 فرمت قابل قبول</li>
                                    </ul>
                                </div>
                                <div class="button-container reight full">
                                    <span onclick="document.getElementById('port_form').submit()" class="butt">ذخیره تغییرات</span>
                                </div>

                            </div>
                        </div>
                    </div>
                    </form>
                    <div class="row">
                        <div class="col-lg-12">
                            <div>

                                <div class="instruction">
                                    <h3>دستور العمل ضبط ویدئو معرفی</h3>

                                    <div class="about-text">
                                        <div>
                                            <p> به عنوان یک استاد جدید در سایت: ویدئو مهمترین و اصلی ترین فاکتور برای جذب زبان آموز میباشد. اگر به هر دلیلی نتوانید خودتان را به شکلی مناسب معرفی نمایید، زبان آموزان شما را انتخاب نخواهند کرد</p>
                                            <p> به عنوان یک استاد جدید در سایت: ویدئو مهمترین و اصلی ترین فاکتور برای جذب زبان آموز میباشد. اگر به هر دلیلی نتوانید خودتان را به شکلی مناسب معرفی نمایید، زبان آموزان شما را انتخاب نخواهند کرد</p>
                                        </div>
                                    </div>

                                    <div class="about-more">
                                        <div>

                                            <span> خواندن ادامه</span>
                                            <span class="down">
																	<i class="icon-down"></i>
																	<i class="icon-down"></i>
																</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="more-video">
                                    <h3>تعدادی از ویدیو های مناسب از دید اُتیچر</h3>
                                    <div class="row">
                                        <div class="col-lg-6 col-md-12">
                                            <div>

                                                <div class="jquery_videoplayer">
                                                    <div class="video_play_icon"></div>
                                                    <video controls="">
                                                        <source src="images/video.mp4" type="video/mp4">
                                                    </video>
                                                    <div class="controller">
                                                        <div class="fullscreen">FullScreen</div>
                                                        <div class="volume horizontal slider">
                                                            <div class="slider_bar"></div>
                                                            <div class="handle"></div>
                                                        </div>
                                                        <div class="audio">Mute</div>
                                                        <div class="timing">
                                                            <span class="time">00:00</span> / <span class="duration">00:00</span>
                                                        </div>
                                                        <div class="playpause">Play/Pause</div>
                                                        <div class="progressbar_wrapper">
                                                            <div class="pbar"></div>
                                                            <div class="buffer"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-12">
                                            <div>

                                                <div class="jquery_videoplayer">
                                                    <div class="video_play_icon"></div>
                                                    <video controls="">
                                                        <source src="images/video.mp4" type="video/mp4">
                                                    </video>
                                                    <div class="controller">
                                                        <div class="fullscreen">FullScreen</div>
                                                        <div class="volume horizontal slider">
                                                            <div class="slider_bar"></div>
                                                            <div class="handle"></div>
                                                        </div>
                                                        <div class="audio">Mute</div>
                                                        <div class="timing">
                                                            <span class="time">00:00</span> / <span class="duration">00:00</span>
                                                        </div>
                                                        <div class="playpause">Play/Pause</div>
                                                        <div class="progressbar_wrapper">
                                                            <div class="pbar"></div>
                                                            <div class="buffer"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="cover">


                </div>
            </div>
        </li>
        <li class="tabv">



            <div class="account-setting">




                <div class="row">


                    <div class="col-lg-6 col-md-12">
                        <div>
                            <img src="/home/images/authentication.png" alt="">
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12">
                        <div>

                            <?php if($errors->any()): ?>
                                <div class="e_section" id="e_section">
                                    <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                </div>
                            <?php endif; ?>
                            <form id="repass" action="<?php echo e(route('teacher.save.password',$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <?php echo method_field('post'); ?>

                                <div class="input-container fill">
                                    <label for="">کلمه عبور فعلی</label>
                                    <i class="icon-key"></i>
                                    <input type="text" value="<?php echo e(\Illuminate\Support\Facades\Crypt::decryptString($user->password)); ?>" placeholder="‏">
                                </div>

                                <div class="input-container fill">
                                    <label for="">کلمه عبور جدید</label>
                                    <i class="icon-lock"></i>
                                    <input type="text" name="password" placeholder="‏">
                                </div>

                                <div class="input-container fill">
                                    <label for="">تکرار کلمه عبور</label>
                                    <i class="icon-lock"></i>
                                    <input type="text" name="password_confirmation" placeholder="‏">
                                </div>

                                <div class="button-container reight">
                                    <span  onclick="document.getElementById('repass').submit()" class="butt">ذخیره تغییرات</span>
                                </div>
                            </form>

                        </div>
                    </div>


                </div>
            </div>

        </li>
    </ul>

</div>


    <?php if (isset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02)): ?>
<?php $component = $__componentOriginal405004b71fef127582a15064122221f6b5f1ca02; ?>
<?php unset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/profile/profile.blade.php ENDPATH**/ ?>