<div id="sidemenu">
    <div>

			<span class="close">
				<i class="icon-cancel"></i>
			</span>
        <div id="slogo">
            <a href="#">
                <i class="icon-logo"></i>
                <span>Teacherpro</span>
            </a>
        </div>

        <div id="ssearch">
            <form action="#">
                <input type="text" placeholder="جست و جو ">
                <button><i class="icon-search"></i></button>
            </form>
        </div>

        <div id="scat">
				<span>
					<i class="icon-cats"></i>
					<span>دسته بندی ها</span>
					<i class="icon-down"></i>
				</span>
            <ul>
                <li><a href="#">طراحی وب سایت</a></li>
                <li><a href="#">علوم کامپیوتر</a></li>
                <li><a href="#">علوم داده</a></li>
                <li><a href="#">مهندسی</a></li>
                <li><a href="#">ریاضیات</a></li>
                <li><a href="#">معماری</a></li>
                <li><a href="#">مطالعه تجارت</a></li>
                <li><a href="#">طراحی و هنر</a></li>
            </ul>
        </div>




        <div id="smenu">
            <ul>
                <li class="active"><a href="<?php echo e(route('home.teacher.register')); ?>">جست و جوی استاد</a></li>
                <li class="parent"><a href="#">دوره آموزشی</a>

                    <ul>
                        <li><a href="#">زیر منو</a></li>
                        <li class="parent"><a href="#">زیر منو</a>

                            <ul>
                                <li><a href="#">زیر منو</a></li>
                                <li><a href="#">زیر منو</a></li>
                                <li><a href="#">زیر منو</a></li>
                                <li><a href="#">زیر منو</a></li>
                                <li><a href="#">زیر منو</a></li>
                            </ul>
                        </li>
                        <li><a href="#">زیر منو</a></li>
                        <li><a href="#">زیر منو</a></li>
                        <li><a href="#">زیر منو</a></li>
                    </ul>

                </li>
                <li><a href="#">صفحات</a></li>
                <li><a href="#">درباره ما</a></li>
                <li><a href="#">تماس با ما</a></li>
            </ul>
        </div>

    </div>

</div>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/section/sidebar_home.blade.php ENDPATH**/ ?>