<?php $__env->startComponent('home.teacher.content',['title'=>' تنظیمات  ']); ?>


    <div id="teacherpish">

        <?php $__env->slot('bread'); ?>


            <div id="toppish">
                <div class="right">

                    <div class="bread">
                        <ul>
                            <li><a href="#">تیچرپرو</a></li>
                            <li><span><i class="icon-left"></i></span></li>
                            <li><span>پنل استاد</span></li>
                        </ul>
                    </div>

                </div>
                <div class="left">

                    <ul class="icon-menue">

                        <li><a href="#"><i class="icon-plus"></i></a></li>
                        <li><a href="#"><i class="icon-smile"></i></a></li>
                        <li><a href="#"><i class="icon-bell"></i><span class="num">3</span></a></li>
                        <li class="exit"><a href="#"><i class="icon-exit"></i><span>خروج</span></a></li>
                    </ul>
                </div>
            </div>


        <?php $__env->endSlot(); ?>






    </div>

    <div id="article-from" class="shade">

        <div class="widget-title">
            <h3>مقاله جدید</h3>
            <div class="dot3">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="widget-content">




            <form action="<?php echo e(route('Article.store',['user_id'=>$user->id])); ?>" enctype="multipart/form-data" class=" " method="post"  >
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>


                <div class="row">
                    <div class="col-lg-9 col-md-12">
                        <div>

                            <div class="input-container fill">
                                <label for="">عنوان مقاله  <span>(حداكثر 70 كاراكتر)</span></label>
                                <input type="text" name="title" value="<?php echo e(old('title' )); ?>"  placeholder="‏عنوان مقاله را بنويسيد">
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                        </div>
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <div>
                            <div class="input-container fill">
                                <label for="">تصویر شاخص</label>
                                <input type="file" name="image" placeholder="انتخاب کن" accept="image/*">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div>














                            <div class="input-container fill">
                                <label for="">  دسته بندی ها</label>
                                <select name="cat[]" id="" class="select2" multiple>
                                    <option >لطفا یک مورد را انتخاب کنید </option>
                                    <?php $__currentLoopData = \App\Models\Acat::whereNull('parent_id')->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(\App\Models\Acat::where('parent_id',$ac->id)->latest()->get()->first()  ): ?>
                                            <optgroup  label="<?php echo e($ac->name); ?>" >
                                                <?php $__currentLoopData = \App\Models\Acat::where('parent_id',$ac->id)->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e((in_array($accc->id,old('cat',[] ))?'selected':'')); ?>  value="<?php echo e($accc->id); ?>"><?php echo e($accc->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php else: ?>
                                            <optgroup  label="<?php echo e($ac->name); ?>" >
                                                <option <?php echo e((in_array($ac->id,old('cat' ,[]))?'selected':'')); ?> value="<?php echo e($ac->id); ?>"><?php echo e($ac->name); ?></option>
                                            </optgroup>
                                        <?php endif; ?>


                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div>
                            <textarea name="article" id="mytextarea"><?php echo e(old('article' )); ?></textarea>
                            <?php $__errorArgs = ['article'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div>
                            <div class="add-tag">
                                <h4><span class="hs">#</span>افزودن تگ ها <span>(حداكثر 5 تا)</span></h4>
                                <?php $__errorArgs = ['tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <div class="form">
                                    <input type="text" placeholder="كلمات كليدی">
                                    <span class="addt">افزودن</span>
                                </div>
                                <div class="result">
                                    <?php if(  old('tag')): ?>
                                    <?php $__currentLoopData = old('tag'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $old): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span><input name="tag[]" hidden="" value="<?php echo e(($old)); ?>"> <?php echo e($old); ?><i class="icon-close"></i></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-12">
                        <div>
                            <div class="button-container reight">
                                <input type="submit" class="bt" value="انتشار پست" name="save">
                            </div>
                            <div class="button-container reight border">
                                <input type="submit" class="btr" value="  ذخیره پیشنویس" name="draft">
                            </div>

                        </div>
                    </div>
                </div>


            </form>



        </div>


    </div>


<?php if (isset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02)): ?>
<?php $component = $__componentOriginal405004b71fef127582a15064122221f6b5f1ca02; ?>
<?php unset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/profile/create_articles.blade.php ENDPATH**/ ?>