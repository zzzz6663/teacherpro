<?php $__env->startComponent('home.teacher.content',['title'=>' تنظیمات  ']); ?>


<div id="teacherpish">

    <?php $__env->slot('bread'); ?>

        <?php echo $__env->make('home.teacher.profile.bread_left',['name'=>'    برنامه زمانی'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->endSlot(); ?>






        <div id="time-pannel" class="shade">

            <div class="widget-title">
                <h3>برنامه زمانی</h3>
                <div class="dot3">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>

            <div class="widget-content">

                <div class="calendar-guide">
                    <h4>راهنمای تقویم و نحوه زمان بازکردن در برنامه زمانی</h4>
                    <div class="gray-box">
                        <img src="images/calendar_two_color.png" alt="">

                        <ul>
                            <li>هر سلول در داخل تقویم به نشانه‌ی ۳۰ دقیقه است.</li>
                            <li>برای اضافه کردن زمان به تقویم روی هر سلول شروع به کشیدن و رها کردن (Drag & Drop) کنید.</li>
                            <li>برای ثبت تغیرات زمانی، بعد از انجام تغیرات روی گزینه ثبت بزنید.</li>
                            <li>خانه های قرمز رنگ به معنای زمان های مورد نظر برای حذف شدن از تقویم است.</li>
                            <li>خانه های سبز رنگ به معنای زمان‌های آزاد شما می باشد.</li>
                            <li>خانه‌های سفید رنگ به معنای زمان‌های غیرفعال شما در تیچرپرو می باشد.</li>
                            <li>خانه های خاکستری رنگ به معنای زمان های رزروشده توسط زبان‌آموز هست و شما می بایست در این زمان‌ها کلاس خود را برگزار کنید.</li>
                        </ul>

                    </div>
                </div>



                <div class="teacher-guide">
                    <div class="row">
                        <div class="col-lg-12">
                            <?php if($errors->any()): ?>
                                <div class="e_section" id="e_section">
                                    <span class="text text-danger">حداقل یک زمان انتخاب کنید </span><br>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <div>
                                <div class="title">
												<span>

													راهنمای تقویم :
												</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12">
                            <div>
                                <ul>
                                    <li>
                                        <span class="titl">قابل رزرو</span>
                                        <span class="color green"></span>
                                    </li>
                                    <li>
                                        <span class="titl">رزروشده</span>
                                        <span class="color gray"></span>
                                    </li>
                                    <li>
                                        <span class="titl">غیرفعال</span>
                                        <span class="color wgray"></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-12">
                            <div>
                                <div class="time-zone">
                                    <i class="icon-timezone"></i>
                                    <span>منطقه زمانی :</span>
                                    <span>Asia/Tehran</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <div id="teacher-clander" data-name="عرفان آماده" data-job="استاد مجرب" data-pic="images/teacher.jpg">
                    <div class="right">
                        <div class="hours">
                            <ul>
                                <li>
                                    <span>AM</span>
                                    <span>07:00</span>
                                </li>
                                <li>
                                    <span>AM</span>
                                    <span>08:00</span>
                                </li>
                                <li>
                                    <span>AM</span>
                                    <span>09:00</span>
                                </li>
                                <li>
                                    <span>AM</span>
                                    <span>10:00</span>
                                </li>
                                <li>
                                    <span>AM</span>
                                    <span>11:00</span>
                                </li>
                                <li>
                                    <span>AM</span>
                                    <span>12:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>13:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>14:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>15:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>16:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>17:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>18:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>19:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>20:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>21:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>22:00</span>
                                </li>
                                <li>
                                    <span>PM</span>
                                    <span>23:00</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="cond">

                        <form id="plan" action="<?php echo e(route('teacher.save.plan',$teacher->id)); ?>" method="post" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>
                        </form>
                        <ul class="   ">
                            <?php for($i=0 ;$i<7;$i++): ?>
                                <li data-date="<?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::now()->addDay($i))->format('%A, %d %B %y')); ?>">
                                <div class="date">
                                    <span class="top"> </span>
                                    <span class="bot">
                                          <?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::now()->addDay($i))->format('%A, %d %B  ')); ?>


                                    </span>
                                </div>
                                <?php for($p=0 ;$p<34;$p++): ?>

                                    <?php
                                        $today= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                        $today5= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                    ?>




                                <div   class="hour <?php echo e(($teacher->empty($today->addMinutes(($p*30))->format('Y-m-d H:i:s')))?' certain ':'    '); ?> <?php echo e(($teacher->reserved($today5->addMinutes(($p*30))->format('Y-m-d H:i:s')))?'  reserved  ':'  '); ?>" data-time="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))); ?>" >
                                    <input type="checkbox" form="plan" class="op" name="reserve[]" value="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))); ?>" hidden  >
                                    <input type="checkbox" form="plan" class="can" name="can[]" value="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))); ?>" hidden  >
                                </div>




                                <?php endfor; ?>

                            </li>
                            <?php endfor; ?>
                        </ul>


                    </div>
                </div>


                <div class="button-container reight">
                    <input class="bt" type="submit" form="plan" value="ذخیره تغییرات">

                </div>

            </div>


        </div>

</div>


    <?php if (isset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02)): ?>
<?php $component = $__componentOriginal405004b71fef127582a15064122221f6b5f1ca02; ?>
<?php unset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/profile/plans.blade.php ENDPATH**/ ?>