<?php $__env->startComponent('admin.section.content',['title'=>'لیست کاربران']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست دسته بندی ها</li>
    <?php $__env->endSlot(); ?>


    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست  دسته بندی ها</h3>
                            <div class="card-tools">
                                <div class="btn-group-sm">
                                    
                                </div>
                            </div>
                            <div class="card-tools">
                                <div class="btn-group-sm">
                                    <a class="btn btn-info" href="<?php echo e(route('acats.create')); ?>">create new</a>
                                </div>
                            </div>












                        </div>

                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody><tr>
                                    <th>شماره</th>
                                    <th>نام </th>
                                    <th>  سرشاخه</th>
                                    <th>  ویرایش</th>
                                </tr>
                                <?php $__currentLoopData = \App\Models\Acat::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($acat->name); ?></td>
                                        <td>
                                            <?php echo e((\App\Models\Acat::find($acat->parent_id))?\App\Models\Acat::find($acat->parent_id)->name:''); ?></td>
                                        <td>
                                            <a  href="<?php echo e(route('acats.edit',$acat->id)); ?>" class="btn btn-primary">edit</a>
                                            <form style="display: inline-block" action="<?php echo e(route('acats.destroy',$acat->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <input  type="submit" class="btn btn-danger" value="delete">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
        <div class="col-md-12">



        </div>
    </div>
<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\teacherpro\resources\views/admin/acat/all.blade.php ENDPATH**/ ?>