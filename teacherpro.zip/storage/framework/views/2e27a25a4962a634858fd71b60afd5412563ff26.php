<?php $__env->startComponent('admin.section.content',['title'=>' داشبورد']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item">پنل مدیریت</li>
     <?php $__env->endSlot(); ?>

<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\teacherpro\resources\views/admin/index.blade.php ENDPATH**/ ?>