<?php $__env->startComponent('home.student.content',['title'=>' تنظیمات  ']); ?>



        <?php $__env->slot('bread'); ?>

            <?php echo $__env->make('home.student.profile.bread_left',['name'=>'داشبورد'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php $__env->endSlot(); ?>

<div class="teacher-pricing shade" id="lang">
        <div class="widget-title">
            <h3 id="res_student" data-user="<?php echo e($teacher->id); ?>" data-count="<?php echo e($count->id); ?>">     اضافه کردن   </h3>

            <div class="dot3">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="widget-content">



    <div class="time-toptext">
        <h3>
            انتخاب تاریخ و زمان برگذاری
            <br>
            <br>
            <?php echo e(($count->count)); ?>

            کلاس انتخاب نشده
        </h3>
        <p>برای رزرو کلاس، زمان مورد نظر را از بین خانه های سبز رنگ انتخاب و تایید نمایید</p>
    </div>

    <div class="teacher-guide">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div>
                    <div class="title">
												<span>
													راهنمای تقویم :
												</span>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12">
                <div>
                    <ul>
                        <li>
                            <span class="titl">قابل رزرو</span>
                            <span class="color green"></span>
                        </li>
                        <li>
                            <span class="titl">رزروشده</span>
                            <span class="color gray"></span>
                        </li>
                        <li>
                            <span class="titl">غیرفعال</span>
                            <span class="color wgray"></span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-12">
                <div>
                    <div class="time-zone">
                        <i class="icon-timezone"></i>
                        <span>منطقه زمانی :</span>
                        <span>Asia/Tehran</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

            <div id="teacher-clander" data-name="<?php echo e($teacher->name); ?>" data-job="<?php echo e(($teacher->attr('experienced'))?'(مجرب)':''); ?> <?php echo e(($teacher->attr('motivated'))?'(با انگیزه)':''); ?>  <?php echo e(($teacher->attr('accepted'))?'(پذیرفته شده)':''); ?>" data-pic="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>">
                <div class="right">
                    <div class="hours">
                        <ul>
                            <li>
                                <span>AM</span>
                                <span>07:00</span>
                            </li>
                            <li>
                                <span>AM</span>
                                <span>08:00</span>
                            </li>
                            <li>
                                <span>AM</span>
                                <span>09:00</span>
                            </li>
                            <li>
                                <span>AM</span>
                                <span>10:00</span>
                            </li>
                            <li>
                                <span>AM</span>
                                <span>11:00</span>
                            </li>
                            <li>
                                <span>AM</span>
                                <span>12:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>13:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>14:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>15:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>16:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>17:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>18:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>19:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>20:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>21:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>22:00</span>
                            </li>
                            <li>
                                <span>PM</span>
                                <span>23:00</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="con">
                    <?php


                    ?>
                    <ul class=" owl-carousel owl-theme ">
                        <?php for($i=0 ;$i<12;$i++): ?>
                            <li class="par"   data-date=" <?php echo e(verta(\Carbon\Carbon::now()->addDay($i))->format('Y-n-j H:i')); ?> ">

                                <div class="date">
                                    <span class="top"> </span>
                                    <span class="bot">
                                          <?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::now()->addDay($i))->format('%A, %d %B  ')); ?>

                                           </span>
                                </div>

                                <?php for($p=0 ;$p<34;$p++): ?>

                                    <?php
                                        $today= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                        $today2= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                        $today4= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                        $today3= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                        $today5= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                    ?>

                                    <?php if($today->addMinutes(($p*30))->greaterThan(\Carbon\Carbon::now() )): ?>

                                        <div data-level="student" data-ps="sssf"

                                             data-id="<?php echo e($teacher->id); ?>"    class="hour <?php echo e(($teacher->empty($today2->addMinutes(($p*30))->format('Y-m-d H:i:s')))?' open ':' '); ?>  <?php echo e(($teacher->reserved($today5->addMinutes(($p*30))->format('Y-m-d H:i:s')))?'  reserved  ':'  '); ?>" data-cid="<?php echo e($teacher->empty($today4->addMinutes(($p*30))->format('Y-m-d H:i:s'))); ?>"
                                             data-da="

                                            <?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30)))->format('%A, %d %B ')); ?>

                                                 "
                                             data-time="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))->format('H:i:s')); ?>"
                                                >
                                            <input type="checkbox" form="plan" class="op" name="reserve[]" value="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))); ?>" hidden  >
                                        </div>

                                    <?php else: ?>
                                        <div   class="hour <?php echo e(($teacher->empty($today3->addMinutes(($p*30))->format('Y-m-d H:i:s')))?'   ':''); ?>" data-time="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))->format('H:i:s')); ?>" >
                                            <input type="checkbox" form="plan" class="op" name=" " value="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))); ?>" hidden  >
                                        </div>
                                    <?php endif; ?>
                                <?php endfor; ?>


                            </li>
                        <?php endfor; ?>

                    </ul>
                </div>
            </div>



            <div id="nextstep" class="nextstep" hidden>
        <div class="left">
            <img src="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>" alt="">

        </div>
        <div class="right">
            <div class="eteb">
                <ul>
                    <li>زمان انتخابی شما  :</li>
                    <li class="ico"><i class="icon-calender"></i><span id="date_e">   </span></li>
                    <li class="ico"><i class="icon-time-line"></i><span id="time_e">  </span></li>
                </ul>
            </div>
            <ul class="etmen">
                <li>
                    <div id="s_reserve" class="button-container reight">
                        <span class="butt">  تایید</span>
                    </div>
                </li>





            </ul>
        </div>
    </div>
        </div>
        </div>

    <?php if (isset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3)): ?>
<?php $component = $__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3; ?>
<?php unset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/student/profile/reserve.blade.php ENDPATH**/ ?>