<?php $__env->startSection('main_body'); ?>
    <div id="maincontent" class="rows">
        <div>


            <div class="popw shade">


            </div>
            <div class="popupc" style="display: block">
                <div>
                    <div>
                        <div>

                            <div class="popup-container shade">
						<span class="closse">
							<i class="icon-cancel"></i>
						</span>

                                <div class="paypop green">
                                    <div class="icon">
                                        <img src="/home/images/hapypay.svg" alt="" class="t">
                                        <img src="/home/images/hapypaybg.svg" alt="" class="b">
                                    </div>
                                    <div class="title">
                                        <h3>
                                            <img src="/home/images/card.svg" alt="">
                                            <span>پرداخت با موفقیت انجام شد</span>
                                        </h3>
                                    </div>
                                    <div class="text">
                                        <span>شماره سریال پرداختی شما  : </span>
                                        <span><?php echo e($bill->transactionId); ?></span>
                                    </div>
                                    
                                    
                                    
                                    <div class="button-container reight">
                                        <span onclick="window.location.href='<?php echo e(route('student.wallet')); ?>'" class="butt"><i class="icon-dashboard"></i>ورود به داشبورد</span>

                                        




                                    </div>
                                </div>


                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\teacherpro\resources\views/home/pay_success.blade.php ENDPATH**/ ?>