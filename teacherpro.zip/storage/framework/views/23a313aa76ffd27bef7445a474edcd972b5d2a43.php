<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">          نوشته
                        <?php echo e($user->name); ?>

                        <?php echo e($article->title); ?>


                    </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
                        <li class="breadcrumb-item"><a href="/admin/teachers">   پروفایل معلم</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.teacher.edit',$user->id)); ?>">   پروفایل <?php echo e($user->name); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.teacher.article',$user->id)); ?>">   نوشته ها <?php echo e($user->name); ?></a></li>
                        <li class="breadcrumb-item">        <?php echo e($article->title); ?> </li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>

    <div class="row">
        <!-- /.col -->
        <div class="col-md-12">
            <!-- Box Comment -->
            <div class="card card-widget">
                <div class="card-header">
                    <div class="user-block">
                        <span class="username"><?php echo e($article->title); ?></span>
                        <span class="description"> <?php echo e(\Morilog\Jalali\Jalalian::forge($article->created_at)->ago()); ?></span>
                    </div>
                    <!-- /.user-block -->

                    <!-- /.card-tools -->
                </div>
                <div class="card-body">
                    <img src="<?php echo e(asset('/src/article/images/'.$article->image)); ?>" alt="">
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <?php echo $article->article; ?>

                </div>


                <div class="card-body">
                    <h1>دسته بندی ها</h1>
                    <?php
                        $cats=$article->acats;

                    ?>
                    <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <small class="badge badge-info">  <?php echo e($cat->name); ?>  </small>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card-body">
                    <h1>تگ ها</h1>
                  <?php
                      $tag=$article->tag;
                        $tag=explode('__',$tag);
                  ?>
                    <?php for($i=0; $i<sizeof($tag); $i++): ?>
                        <small class="badge badge-info">  <?php echo e($tag[$i]); ?>   </small>
                        <?php endfor; ?>
                </div>

            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>


    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('.master.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\teacherpro\resources\views/admin/teacher/teacher_article_show.blade.php ENDPATH**/ ?>