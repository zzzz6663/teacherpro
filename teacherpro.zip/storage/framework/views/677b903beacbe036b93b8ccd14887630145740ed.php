                <?php $__env->startSection('main_body'); ?>



                    <div id="topheader" class="rows">
                        <div class="container">
                            <div>

                                <h2 >آرشیو مقالات</h2>
                            </div>
                        </div>
                    </div>

                    <div id="page" class="rows">
                        <div class="container">

                            <div class="tablc">
                                <div class="tabler">



                                    <div id="main">
                                        <div>
                                            <div class="row">

                                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-lg-4 col-sm-6 col-xsm-12">
                                                    <div>
                                                        <div class="single-post">

                                                            <div class="elementor-post__card">
                                                                <a class="elementor-post__thumbnail__link" href="#">
                                                                    <div class="elementor-post__thumbnail elementor-fit-height">
                                                                        <img src="<?php echo e(asset('/src/article/images/a3'.$article->image)); ?>" alt="">
                                                                    </div>
                                                                </a>
                                                                <div class="elementor-post__badge"><?php echo e($article->acats()->first()->name); ?></div>
                                                                <div class="elementor-post__text">
                                                                    <h3 class="elementor-post__title">
                                                                        <a href="<?php echo e(route('home.single.article',$article->id)); ?>"> <?php echo e($article->title); ?>  </a>
                                                                    </h3>
                                                                    <div class="elementor-post__excerpt">

                                                                    </div>
                                                                </div>
                                                                <?php ($v=verta($article->created_at)); ?>
                                                                <div class="elementor-post__meta-data">
                                                                    <span class="elementor-post-author"> <?php echo e($article->user->name); ?> </span>
                                                                    <span class="elementor-post-date"><?php echo e($v->format('%B %d، %Y')); ?></span>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div>
                                                        <?php echo e($articles->appends(request()->all())->links('home.section.pagination2')); ?>


                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div id="sidebar">
                                        <div>


                                            <?php echo $__env->make('home.section.side_article', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>



                <?php $__env->stopSection(); ?>








<?php echo $__env->make('master.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\teacherpro\resources\views/home/articles.blade.php ENDPATH**/ ?>