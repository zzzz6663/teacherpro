<?php $__env->startComponent('home.student.content',['title'=>' تنظیمات  ']); ?>



        <?php $__env->slot('bread'); ?>

            <?php echo $__env->make('home.student.profile.bread_left',['name'=>'داشبورد'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php $__env->endSlot(); ?>

<div class="teacher-pricing shade" id="lang">
        <div class="widget-title">
            <h3 id="res_student" >معلم های برگزیده</h3>

            <div class="dot3">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="widget-content">

            <?php if( !auth()->user()->sfave()->get()->first() ): ?>
                <a href="<?php echo e(route('home.teacher.list')); ?>" class="bt">انتخاب استاد</a>
            <?php endif; ?>
            <?php $__currentLoopData = auth()->user()->sfave()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($teacher=\App\Models\User::find($fave->teacher_id)); ?>

                <div class="teachers-list">

                    <div class="single-teacher shade">
                        <div class="rowd">
                            <div class="teacher-right">
                                <div>

                                    <div class="teacher-det">


                                        <div class="det-r">

                                            <div class="tlinks">
                                                <a href="#" class="reserv">رزرو جلسه رایگان</a>
                                            </div>

                                            <div class="img">
                                                <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                                                    <?php if(auth()->user()->level=='student'): ?>
                                                        <form id="form_save_<?php echo e($teacher->id); ?>" action="<?php echo e(route('student.fave.teachers',$teacher->id)); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('post'); ?>
                                                            <input type="text" hidden name="teacher" value="<?php echo e($teacher->id); ?>">

                                                        </form>
                                                        <span data-id="<?php echo e($teacher->id); ?>" class="like fave_teacher"><i style="color: <?php echo e((auth()->user()->has_fave($teacher->id))?'red':''); ?>" class="icon-heart"></i></span>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <img src="<?php echo e(asset('/src/avatar/'.$teacher->attr('avatar'))); ?>" alt="">
                                            </div>

                                            <ul>
                                                <li class="name">
                                                    <span class="pointer" onclick="window.location.href='<?php echo e(route('home.teacher.profile',$teacher->id)); ?>'">  <?php echo e($teacher->name); ?></span>
                                                </li>
                                                <li class="ti">
                                                    <span>  <?php echo e(($teacher->attr('experienced'))?'مجرب':''); ?></span>
                                                    <span>  <?php echo e(($teacher->attr('motivated'))?'با انگیزه':''); ?></span>
                                                    <span>  <?php echo e(($teacher->attr('accepted'))?'پذیرفته شده':''); ?></span>
                                                </li>
                                                <li class="rate">
                                                    <i class="icon-star gray"></i>
                                                    <i class="icon-star gray"></i>
                                                    <i class="icon-star"></i>
                                                    <i class="icon-star"></i>
                                                    <i class="icon-star"></i>
                                                    <span>3/5</span>
                                                </li>
                                            </ul>

                                        </div>


                                        <div class="det-l">

                                            <div class="teaching-lng">
													<span class="title">
														 زبان تدریس  :
													</span>
                                                <ul>
                                                    <?php $__currentLoopData = $teacher->languages()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><img style="height: 25px;width: 25px;" src="<?php echo e(asset('/src/img/lang/'.$lang->img)); ?>" alt=""><span><?php echo e($lang->name); ?></span></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                            <ul>
                                                <li class="classes">
                                                    <span class="num">46</span>
                                                    <span class="nam">
															<i class="icon-training"></i>
															<span>کلاس ها</span>
														</span>
                                                </li>
                                                <li class="student">
                                                    <span class="num">446</span>
                                                    <span class="nam">
															<i class="icon-cap"></i>
															<span>زبان‌آموزان</span>
														</span>
                                                </li>
                                            </ul>
                                            <ul>
                                                <li class="price">
                                                    <span>قیمت هر جلسه (هر ساعت)</span>
                                                </li>
                                                <li class="mprice">
                                                    <span class="num"><?php echo e(number_format($teacher->com_price($teacher->attr('meet1')))); ?></span>
                                                    <span class="cur">ریال</span>
                                                    
                                                </li>
                                                
                                                
                                                
                                                
                                            </ul>
                                        </div>
                                    </div>



                                </div>
                            </div>
                            <div class="teacher-left">
                                <div>
                                    <div class="tabs">
                                        <ul class="tab-nav">
                                            <li class="active"><span><span>ویدیو </span><i class="icon-video-on"></i></span></li>
                                            <li><span><span>درباره </span><i class="icon-about"></i></span></li>
                                        </ul>
                                        <ul class="tab-container">
                                            <li class="active">
                                                <div>



                                                    <video   class="js-player" playsinline controls data-poster="<?php echo e(asset('/src/port_img/'.$teacher->attr('port_img'))); ?>">
                                                        <source src="<?php echo e(asset('/src/port_vid/'.$teacher->attr('port_vid'))); ?>" type="video/mp4" />
                                                    </video>

                                                </div>
                                            </li>
                                            <li>
                                                <div>
                                                    <p>
                                                        <?php echo e($teacher-> bio); ?>


                                                        <a href="<?php echo e(route('home.teacher.profile',$teacher->id)); ?>"> خواندن ادامه <i class="icon-left"></i><i class="icon-left"></i></a>

                                                    </p>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>



</div>

    <?php if (isset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3)): ?>
<?php $component = $__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3; ?>
<?php unset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/student/profile/fave.blade.php ENDPATH**/ ?>