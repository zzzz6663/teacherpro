<?php $__env->startComponent('home.student.content',['title'=>' تنظیمات  ']); ?>


<div id="teacherpish">

    <?php $__env->slot('bread'); ?>

        <?php echo $__env->make('home.student.profile.bread_left',['name'=>'حساب  کاربری'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->endSlot(); ?>




</div>

<div class="profile-settings shade">
    <div class="dot3">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <ul class="tab-nav" id="jtab">
        <li class="taby active"   ><span>پروفایل</span></li>
        <li class="taby" ><span>رمز عبور</span></li>
    </ul>




    <ul class="tab-container tabv">
        <li class="active tabv">

            <div class="profile-setting">
                <div class="cover">

                    <?php if(file_exists(public_path('/src/bg/'.$user->attr('bg'))) && !empty($user->attr('bg'))): ?>
                        <img src="<?php echo e(asset('src/bg/bg'.$user->attr('bg'))); ?>" alt="">

                    <?php else: ?>
                        <img src="/home/images/cover.png" alt="">
                    <?php endif; ?>

                    <form action="<?php echo e(route('student.save.bg',$user->id)); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="lable-container">
                            <input id="cover-file" type="file">
                            <input id="profile-files" name="bg" class="avat2" type="file" accept="image/*">
                            <label for="cover-file">
                                <i class="icon-info"></i>
                                <span>کاورپروفایل</span>
                            </label>
                        </div>
                    </form>

                </div>

                <div class="profile-pic">
                    <?php if(file_exists(public_path('/src/avatar/'.$user->attr('avatar')))): ?>
                        <img src="<?php echo e(asset('src/avatar/'.$user->attr('avatar'))); ?>" alt="">
                    <?php else: ?>
                        <img src="/src/avatar/<?php echo e(($user->sex=='male')?'avatar_man.png':'avatar_woman.png'); ?>" alt="">
                    <?php endif; ?>

                    <form action="<?php echo e(route('student.save.avatar',$user->id)); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="lable-container">
                            <input id="profile-file" name="avatar" class="avat" type="file" accept="image/*">
                            <label for="profile-file">
                                <i class="icon-info"></i>
                            </label>
                        </div>
                    </form>
                </div>

                <div class="row">
                    <div class="col-lg-12 col-md-10 col-sm-12 center-block">
                        <div>
                            <div class="profile-form">



                                    <?php if($errors->any()): ?>
                                        <div class="e_section" id="e_section">
                                            <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                        </div>
                                    <?php endif; ?>


                                    <form id="info" action="<?php echo e(route('student.profile.save.info',$user->id)); ?>" class=" " method="post"  >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>

                                    <div class="input-container fill">
                                        <label for="">نام و نام خانوادگی</label>
                                        <i class="icon-user"></i>
                                        <input name="name" type="text" value="<?php echo e(old('name',$user->name)); ?>"  placeholder="‏Erfan Amade">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">نام کاربری</label>
                                        <input name="username" readonly type="text" value="<?php echo e(old('username',$user->username)); ?>"  placeholder="‏cQXHR">
                                            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">ایمیل</label>
                                        <input name="email" type="email" value="<?php echo e(old('email',$user->email)); ?>"  placeholder="‏erfanamade@gmail.com">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">شماره موبایل</label>
                                        <input name="mobile" type="number" value="<?php echo e(old('mobile',$user->mobile)); ?>"  placeholder="‏09140252498">
                                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="sex">
                                        <div class="label"> انتخاب جنسیت</div>
                                        <ul>
                                            <li>
                                                <div class="lable-container">
                                                    <input <?php echo e((old('sex',$user->sex)=='male')?'checked':''); ?> type="radio" name="sex" id="male" value="male">
                                                    <label for="male">
                                                        <div>
                                                            <span>مرد</span>
                                                            <i class="icon-male"></i>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="lable-container">
                                                    <input  <?php echo e((old('sex',$user->sex)=='female')?'checked':''); ?>  type="radio" name="sex" id="female" value="female">
                                                    <label for="female">
                                                        <div>
                                                            <span>زن</span>
                                                            <i class="icon-female"></i>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <div class="input-container fill">
                                        <label for="">کشور</label>
                                        <input name="country" type="text" value="<?php echo e(old('country',$user->email)); ?>" placeholder="‏iran (islamic republic of)">
                                        <?php $__errorArgs = ['shaba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="eerror"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>









                                    <div class="button-container reight full">
                                        <input type="submit" class="bt" value="ذخیره تغییرات">
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </li>


        <li class="tabv">



            <div class="account-setting">




                <div class="row">


                    <div class="col-lg-6 col-md-12">
                        <div>
                            <img src="/home/images/authentication.png" alt="">
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12">
                        <div>

                            <?php if($errors->any()): ?>
                                <div class="e_section" id="e_section">
                                    <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                </div>
                            <?php endif; ?>

                                <form id="repass" action="<?php echo e(route('student.save.password',$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <?php echo method_field('post'); ?>

                                <div class="input-container fill">
                                    <label for="">کلمه عبور فعلی</label>
                                    <i class="icon-key"></i>


                                    <input type="text" value="<?php echo e(\Illuminate\Support\Facades\Crypt::decryptString($user->password)); ?>" placeholder="‏">
                                </div>

                                <div class="input-container fill">
                                    <label for="">کلمه عبور جدید</label>
                                    <i class="icon-lock"></i>
                                    <input type="text" name="password" placeholder="‏">
                                </div>

                                <div class="input-container fill">
                                    <label for="">تکرار کلمه عبور</label>
                                    <i class="icon-lock"></i>
                                    <input type="text" name="password_confirmation" placeholder="‏">
                                </div>

                                <div class="button-container reight">
                                    <span  onclick="document.getElementById('repass').submit()" class="butt">ذخیره تغییرات</span>
                                </div>
                            </form>

                        </div>
                    </div>


                </div>
            </div>

        </li>

    </ul>

</div>


    <?php if (isset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3)): ?>
<?php $component = $__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3; ?>
<?php unset($__componentOriginal32b49124baed154b65d6e2b2846190758cfbabe3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/student/profile/profile.blade.php ENDPATH**/ ?>