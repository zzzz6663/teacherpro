<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($v=verta($comment->created_at)); ?>
    <div class="comment">

        <div class="blog-post-comments">
            <div class="right">
                <img alt="" src="<?php echo e(asset('/src/avatar/'.$comment->user->attr('avatar'))); ?>">
            </div>
            <div class="left">
                <div class="top">

                    <span class="blog-post-comment-name">    <?php echo e($comment->user->name); ?>    </span> <span class="date"><?php echo e($v->format('%B %d، %Y')); ?></span>
                    <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                        <a data-id="<?php echo e($comment->id); ?>"  class="pull-left bl pointer add_comment text-gray"><i class="icon2-commenting-o"></i> پاسخ</a>
                    <?php else: ?>
                        <span style="float:left;" class="pointer">
                                                                            برای ثبت پاسخ لطفا وارد
                                                                        <span  class="show_login bl" style="color: #0a8660; font-size: 18px">سایت</span>
                                                                        شوید
                                                                      </span>
                    <?php endif; ?>
                </div>
                <p>
                    <?php echo e($comment->comment); ?>

                </p>

            </div>
        </div>

        <?php echo $__env->make('home.section.comment',['comments'=>$comment->child], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/section/comment.blade.php ENDPATH**/ ?>