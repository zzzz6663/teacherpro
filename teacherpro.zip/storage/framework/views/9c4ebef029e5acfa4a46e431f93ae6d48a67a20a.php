<div id="footer" class="rows">
    <div>
        <div class="row">

            <div class="col-lg-3 col-md-6 col-sm-12">
                <div>
                    <h4>دسترسی سریع</h4>
                    <ul class="nav">
                        <li><a href="<?php echo e(route('home.about.us')); ?>">درباره ما</a></li>
                        <li><a href="<?php echo e(route('home.teacher.register.form')); ?>">جذب استاد</a></li>
                        <li><a href="<?php echo e(route('home.contact.us')); ?>">تماس با ما</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-12">
                <div>
                    <h4>دسته بندی ها</h4>
                    <ul class="nav">
                        <li><a href="#">دوره ها</a></li>
                        <li><a href="#">مقالات</a></li>
                        <li><a href="#">محصولات</a></li>
                        <li><a href="#">نقشه سایت</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-12">
                <div>
                    <h4>راهنمای سایت</h4>
                    <ul class="nav">
                        <li><a href="#">راهنمای استاد</a></li>
                        <li><a href="#">راهنمای زبان آموز</a></li>
                        <li><a href="#">قوانین سایت</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 col-sm-12">
                <div>
                    <h4>تماس با ما</h4>
                    <ul class="nav">
                        <li><a  href="<?php echo e(route('home.contact.us')); ?>">تماس با پشتیبانی</a></li>
                        <li><a href="#">ارسال تیکت</a></li>
                    </ul>

                    <ul class="namd">
                        <li class="enam"></li>
                        <li class="saman"></li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>

<div id="copyright" class="rows">
    <div>
        <span class="backtop"><i class="icon-up"></i></span>

        <div class="right">
            <div class="foot-log">
                <a href="#">
                    <i class="icon-logo"></i>
                    <span>Teacherpro</span>
                </a>
            </div>
            <p>کلیه حقوق این وب سایت برای تیچر پرو محفوظ می‌باشد .</p>
        </div>
        <div class="left">
            <ul class="social">
                <li><a href="#"><i class="icon-aparat"></i></a></li>
                <li><a href="#"><i class="icon-twitter"></i></a></li>
                <li><a href="#"><i class="icon-insta"></i></a></li>
                <li><a href="#"><i class="icon-telegram"></i></a></li>
                <li><a href="#"><i class="icon-in"></i></a></li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/section/footer_home.blade.php ENDPATH**/ ?>