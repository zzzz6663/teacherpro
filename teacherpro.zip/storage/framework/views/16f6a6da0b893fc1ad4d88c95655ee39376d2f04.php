<?php $__env->startComponent('admin.section.content',['title'=>'لیست تراکنش ها']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست   تراکنش ها</li>
    <?php $__env->endSlot(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست تراکنش ها</h3>
                           <div class="card-tools">
                               <div class="btn-group-sm">


                               </div>
                           </div>
                            <div class="card-tools">
                                <form action="<?php echo e(route('admin.bills')); ?>" method="get">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                        <?php echo method_field('get'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="text"  name="search" value="<?php echo e(request('search')); ?>" class="form-control float-right" placeholder="جستجو">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                        </div>
                                </div>
                                </form>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody><tr>
                                    <th>شماره</th>
                                    <th>نام </th>
                                    <th>مبلغ</th>
                                    <th>کمسیون</th>
                                    <th>نوع</th>
                                    <th>وضعیت</th>
                                    <th>پیگیری</th>
                                    <th>تعداد کلاس</th>
                                    <th>تاریخ</th>
                                </tr>
                                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.student.edit',\App\Models\User::find($bill->user->id)->id)); ?>"><?php echo e(\App\Models\User::find($bill->user->id)->name); ?></a>

                                        </td>
                                        <td><?php echo e(number_format(\Illuminate\Support\Facades\Crypt::decryptString($bill->amount))); ?>

                                            ریال</td>

                                        <td>
                                             <?php echo e(number_format($bill->com)); ?>

                                            ریال
                                       </td>
                                        <td><?php echo e(__('arr.'.$bill->type)); ?></td>
                                        <td>
                                            <span class="badge  badge-<?php echo e(($bill->status==1)?'success':'error'); ?> "> <?php echo e(($bill->status==1)?'موفق':'ناموفق'); ?></span>

                                        </td>
                                        <td><?php echo e($bill->transactionId); ?></td>
                                        <td><?php echo e($bill->count); ?></td>
                                        <td><?php echo e(verta($bill->created_at)); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
        <div class="col-md-12">

          <div class="pagi">
              <?php echo e($bills->appends(Request::all())->links('home.section.pagination')); ?>

          </div>

        </div>
    </div>



<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\teacherpro\resources\views/admin/bills.blade.php ENDPATH**/ ?>