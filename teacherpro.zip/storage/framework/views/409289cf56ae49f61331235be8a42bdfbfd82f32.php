<?php $__env->startComponent('home.teacher.content',['title'=>' تنظیمات  ']); ?>



    <?php $__env->slot('bread'); ?>
        <?php echo $__env->make('home.teacher.profile.bread_left',['name'=>'کلاس ها'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?>





        <div class="makeclass shade">
            <div class="widget-title">
                <h3>ایجاد کلاس جدید</h3>
                <div class="dot3">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="widget-content">

                <div class="row">
                    <div class="col-lg-12">
                        <div>
                            <div class="guide-class">
                                <h3>راهنمای ایجاد کلاس</h3>
                                <ul>
                                    <li>هر کلاس تا ۳۰ نفر ظرفیت دارد</li>
                                    <li>زمان جلسات بعدا هم قابل تغییر می باشد</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <div>
                            <div class="right">
                                <img src="/home/images/online_team_meeting__two_color.png" alt="">
                            </div>
                        </div>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="e_section" id="e_section">
                            <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                        </div>
                    <?php endif; ?>


                    <div class="col-lg-7 col-md-12">
                        <div>

                            <form id="free" action="<?php echo e(route('teacher.free.class',$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <div class="input-container fill">
                                    <label for="">نام کلاس</label>
                                    <input id="name" type="text" name="name" placeholder="‏نامی مناسب برای کلاس انتتخاب کنید">
                                </div>






















                                <div class="input-container fill" id="class_parent">






































                                </div>



                                <div class="button-container reight">
                                    <input type="submit" class="bt" value="ایجاد کلاس">
                                    <span class="butt" style="background: #15a6eb; margin-right: 20px" id="new_class_row">اضافه  </span>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<script>
    let  create_new_class=(id)=>{
        return `
                 <div class="text posrel v2" id="boxy_${id}">
                                        <img  class="posab " onclick="document.getElementById('boxy_${id}').remove()" src="/home/css/images/close.png" alt="">
    <ul>
    <li class="num2">
         <select class="em" name="ser[${id}]['day']" id="">
            <option value="">  تاریخ </option>
            <?php for($i=0; $i<7 ;$i++): ?>
               <option value="<?php echo e($day=\Carbon\Carbon::now()->addDays($i)->format('Y-m-d')); ?>"><?php echo e(verta($day)->format('Y-n-j')); ?></option>
            <?php endfor; ?>

        </select>
    </li>
    <li class="num2">
        <select class="em" name="ser[${id}]['du']" id="">
         <option value="">  مدت زمان </option>
            <option value="30">30</option>
            <option value="60">60</option>
            <option value="90">90</option>
            <option value="120">120</option>
            <option value="180">180</option>

        </select>
    </li>
    <li class="num5">
        <select class="em" name="ser[${id}]['h']" id="">
            <option value="">    ساعت </option>
            <?php for($i=7; $i<24 ;$i++): ?>
            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
            <?php endfor; ?>
    </select>
    </li>
    <li class="num4">:</li>
    <li class="num3 ">
        <select class="em" name="ser[${id}]['min']" id="">
            <option value="" >دقیقه</option>
            <option value="30">30</option>
            <option value="00">00</option>

        </select>
    </li>

</ul>

</div>

`
    }
    (function ($) {
        $(document).ready(function () {

            $('body').on('click','#new_class_row',function (e) {
                var class_parent=$('#class_parent')
                var id= class_parent.children().length
                var go= true
                $( ".em" ).each(function( index ) {
                    if ( $( this ).val() ==''){
                        noty('لطفا  همه موارد را پر کنید ')
                        go=false
                        return false

                    }
                });
                if (go){
                    class_parent.append(
                        create_new_class(id)
                    )
                }

            })
        })
    })(jQuery);
</script>

    <?php if (isset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02)): ?>
<?php $component = $__componentOriginal405004b71fef127582a15064122221f6b5f1ca02; ?>
<?php unset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/profile/classes.blade.php ENDPATH**/ ?>