<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/home/css/style.css">
    <link rel="stylesheet" href="/home/css/persianDatepicker-default.css">

    <link rel="stylesheet" href="/home/css/responsive.css">
    <link rel="stylesheet" href="/home/css/iziToast.min.css">
    <link rel="stylesheet" href="/home/css/select2.min.css">
    <link rel="stylesheet" href="/css/app.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(@csrf_token()); ?>">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <script type="text/javascript" src="/home/js/jquery-2.2.0.min.js"></script>


</head>
<body>
<?php echo $__env->make('home.section.sidebar_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="site-content">
    <?php echo $__env->make('home.section.header_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('main_body'); ?>
    <?php echo $__env->make('home.section.footer_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>


<script type="text/javascript" src="/home/js/iziToast.min.js"></script>

<script type="text/javascript" src="/home/js/jquery-ui.js"></script>
<script type="text/javascript" src="/home/js/jquery.videoplayer.js"></script>
<script type="text/javascript" src="/home/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="/home/js/jQuery.countdownTimer.js"></script>
<script type="text/javascript" src="/home/js/jQuery.countdownTimer-fa.js"></script>
<script type="text/javascript" src="/home/js/apexcharts.min.js"></script>
<script type="text/javascript" src="/home/js/tinymce/tinymce.min.js"></script>

<script type="text/javascript" src="/home/js/bootstrap-input-spinner.js"></script>


<script type="text/javascript" src="/home/js/persianDatepicker.min.js"></script>
<script type="text/javascript" src="/home/js/jquery.event.drop-2.2.js"></script>
<script type="text/javascript" src="/home/js/jquery.event.drop.live-2.2.js"></script>
<script type="text/javascript" src="/home/js/jquery.event.drag-2.2.js"></script>
<script type="text/javascript" src="/home/js/jquery.event.drag.live-2.2.js"></script>
<script type="text/javascript" src="/home/js/jquery.mask.min.js"></script>
<script type="text/javascript" src="/home/js/jquery.cookie.js"></script>
<script type="text/javascript" src="/home/js/select2.full.min.js"></script>
<script type="text/javascript" src="/home/js/metisMenu.js"></script>
<script type="text/javascript" src="/home/js/mm-vertical.js"></script>
<script type="text/javascript"  src="/home/js/plyr.min.js"></script>
<script type="text/javascript" src="/home/js/fun.js"></script>
<script type="text/javascript" src="/home/js/template.js"></script>
<script type="text/javascript" src="/home/js/home.js"></script>
<script type="text/javascript" src="/js/app.js"></script>

</body>
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/master/home.blade.php ENDPATH**/ ?>