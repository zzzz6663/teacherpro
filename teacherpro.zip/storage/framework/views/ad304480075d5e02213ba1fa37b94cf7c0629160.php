



        <div id="header" class="rows">
            <div class="fullcontainer">
                <div id="logo">
                    <a href="<?php echo e(route('login')); ?>">
                        <i class="icon-logo"></i>
                        <span>Teacherpro</span>
                    </a>
                </div>
                <div id="top-cat">
					<span>
						<i class="icon-cats"></i>
						<span>دسته بندی ها</span>
					</span>
                    <ul>
                        <li><a href="#">طراحی وب سایت</a></li>
                        <li><a href="#">علوم کامپیوتر</a></li>
                        <li><a href="#">علوم داده</a></li>
                        <li><a href="#">مهندسی</a></li>
                        <li><a href="#">ریاضیات</a></li>
                        <li><a href="#">معماری</a></li>
                        <li><a href="#">مطالعه تجارت</a></li>
                        <li><a href="#">طراحی و هنر</a></li>
                    </ul>
                </div>
                <div id="topsearch">
                    <form action="#">
                        <input type="text" placeholder="جست و جو ">
                        <button><i class="icon-search"></i></button>
                    </form>
                </div>

                <div id="topmenu">
                    <ul>
                        <li class="<?php echo e((Route::currentRouteName()=='home.teacher.list')?'active':''); ?>"><a href="<?php echo e(route('home.teacher.list')); ?>">جست و جوی استاد</a></li>
                        <li class="<?php echo e((Route::currentRouteName()=='home.teacher.register.form')?'active':''); ?> "><a href="<?php echo e(route('home.teacher.register.form')); ?>">  جذب استاد</a></li>
                        <li class="<?php echo e((Route::currentRouteName()=='home.articles')?'active':''); ?> "><a href="<?php echo e(route('home.articles')); ?>">    مقالات</a></li>





















                        <li class="<?php echo e((Route::currentRouteName()=='home.about.us')?'active':''); ?>"><a href="<?php echo e(route('home.about.us')); ?>">درباره ما</a></li>
                        <li class="<?php echo e((Route::currentRouteName()=='home.contact.us')?'active':''); ?>"><a href="<?php echo e(route('home.contact.us')); ?>">تماس با ما</a></li>
                    </ul>
                </div>

                <div id="topleft">
                    <div id="mabnav"><span><i class="icon-menu"></i></span></div>

                    <div id="basket">
                        <a href="#"><i class="icon-basket"></i><span class="num">0</span></a>
                    </div>

                    <div id="usermenu">
                        <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                            <?php if(\Illuminate\Support\Facades\Auth::user()->level=='teacher'): ?>
                                <a href="<?php echo e(route('teacher.dashboard')); ?>"><i class="icon-user"></i></a>
                            <?php else: ?>
                                <a href="<?php echo e(route('student.dashboard')); ?>"><i class="icon-user"></i></a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a id="login" class="bl"><i class="icon-user"></i></a>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>









        <?php if(!\Illuminate\Support\Facades\Auth::check()): ?>
        <div class="popupc" id="login_popup">
            <div>
                <div>
                    <div>

                        <div class="popup-container mini shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>

                            <div class="register-form taby">
                                <div class="tabnav">
                                    <ul class="nav center">
                                        <li ><span>ثبت نام</span></li>
                                        <li  class="active"><span>ورود</span></li>
                                    </ul>
                                </div>

                                <div class="tabcontainer">
                                    <ul>
                                        <li >
                                            <form action="#" method="post" class="bl"  id="submit_form" data-url="<?php echo e(route('home.student.register')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('post'); ?>
                                            <div class="input-container fill">
                                                <label for="name">نام و نام خانوادگی</label>
                                                <i class="icon-user"></i>
                                                <input type="text" name="name" id="name" placeholder="Erfan Amade">
                                            </div>

                                            <div class="input-container   fill">
                                                <label for="email">ایمیل</label>
                                                <i class="icon-mail"></i>
                                                <input type="email" id="email" name="email" placeholder="erfanamade@gmail.com">
                                            </div>

                                                <div class="input-container   fill">
                                                    <label for="username">نام کاربری</label>
                                                    <i class="icon-mail"></i>
                                                    <input type="text" id="username" name="username" placeholder="user">
                                                </div>

                                            <div class="input-container fill">
                                                <label for="mobile">شماره همراه</label>
                                                <i class="icon-phone"></i>
                                                <input type="number" name="mobile" id="mobile" placeholder="     شماره همراه ">
                                            </div>

                                            <div class="input-container fill">
                                                <label for="">رمز عبور</label>
                                                <i class="icon-lock"></i>
                                                <input type="text" name="password" placeholder="کلمه عبور شما">
                                            </div>

                                            <div class="button-container reight">
                                                <input type="submit" class="bt" value="    ثبت نام">
                                            </div>
                                            </form>
                                        </li>
                                        <li class="active">
                                            <form action="#" method="post" id="login_form" class="bl" data-url="<?php echo e(route('home.user.login')); ?>">
                                            <?php echo csrf_field(); ?>
                                                <?php echo method_field('post'); ?>
                                            <div class="input-container fill">
                                                <label for="">آدرس ایمیل شما</label>
                                                <i class="icon-user"></i>
                                                <input type="text" name="email" placeholder="Erfan@Amade.com">
                                            </div>

                                            <div class="input-container fill">
                                                <label for="">رمز عبور</label>
                                                <i class="icon-lock"></i>
                                                <input type="password" name="password" placeholder="کلمه عبور شما">
                                            </div>

                                            <div class="button-container reight">

                                                <input type="submit" class="bt" value="ورود">
                                            </div>
                                            </form>
                                        </li>
                                    </ul>
                                </div>



                            </div>


                        </div>

                    </div>
                </div>
            </div>
        </div>
            <?php endif; ?>



<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/section/header_home.blade.php ENDPATH**/ ?>