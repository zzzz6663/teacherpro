<?php $__env->startComponent('admin.section.content',['title'=>'لیست نوشته  ها']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item">لیست   نوشته  ها</li>
    <?php $__env->endSlot(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">  لیست نوشته  ها</h3>
                           <div class="card-tools">
                               <div class="btn-group-sm">


                               </div>
                           </div>
                            <div class="card-tools">
                                <form action="<?php echo e(route('admin.classes')); ?>" method="get">
                                <div class="input-group input-group-sm" style="width: 150px;">
                                        <?php echo method_field('get'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="text"  name="search" value="<?php echo e(request('search')); ?>" class="form-control float-right" placeholder="جستجو">
                                        <div class="input-group-append">
                                            <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                        </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    <?php if($errors->any()): ?>
                        <?php echo implode('', $errors->all('<span class="text text-danger">:message</span>')); ?>

                    <?php endif; ?>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover">
                                <tbody><tr>
                                    <th>شماره</th>
                                    <th>نام</th>
                                    <th>عنوان</th>
                                    <th>وضعیت</th>
                                    <th>تایید شده</th>
                                    <th>نمایش شده</th>


                                    <th>زمان ثبت</th>
                                </tr>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td> <a href="<?php echo e(route('admin.teacher.edit',\App\Models\User::find($cl->user_id)->id)); ?>"><?php echo e($cl->user->name); ?></td>
                                    <td><?php echo e($cl->title); ?></td>
                                    <td><small class="badge badge-<?php echo e(($cl->active=='1')?'success':'danger'); ?>"><?php echo e(($cl->active=='1')?'ثبت شده':'ثبت نشده'); ?> </small></td>
                                    <td>
                                        <form action="<?php echo e(route('admin.teacher.article.active',$cl->id)); ?>" class=" " method="post"  >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('post'); ?>
                                            <div class="buttons pointer"  >
                                                <button type="submit" class="btn btn-bslock btn-<?php echo e(($cl->submit=='1')?'success':'danger'); ?> btn- "><?php echo e(($cl->submit=='1')?'deactive':'active'); ?></button>

                                                
                                                
                                            </div>
                                        </form>
                                    </td>
                                    <td><a class="btn btn-blsock btn-warning tn-flaیtb" href="<?php echo e(route('admin.teacher.article.show',[$cl->id,$cl->user->id] )); ?>">مشاهده</a></td>
                                    <td><?php echo e(\Morilog\Jalali\Jalalian::forge($cl->created_at)); ?></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody></table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
        <div class="col-md-12">

            <?php echo e($articles->appends(Request::all())->links()); ?>


        </div>
    </div>



<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\teacherpro\resources\views/admin/tarticles.blade.php ENDPATH**/ ?>