<?php $__env->startComponent('home.teacher.content',['title'=>' تنظیمات  ']); ?>


    <div id="teacherpish">

        <?php $__env->slot('bread'); ?>

            <?php echo $__env->make('home.teacher.profile.bread_left',['name'=>'نوشته ها  '], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php $__env->endSlot(); ?>






    </div>
    <div class="article-settings shade">
        <div class="widget-title">
            <h3>نوشته های شما</h3>

            <div class="button-container ">

                <a href="<?php echo e(route('Article.create' )); ?>" class="butt">نوشتن مقاله جدید</a>
            </div>
            <div class="dot3">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>

        <div class="widget-content">


            <ul class="tab-nav">
                <li class="active"><span>منتشر شده</span></li>
                <li><span>پیش‌نویس‌ها</span></li>
                <li><span>نظرات</span></li>
            </ul>



            <ul class="tab-container">
                <li class="active">

                    <div class="article-lits">

                        <?php $__currentLoopData = $artices_active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <div class="single-article-ad">

                            <div class="left">
                                <ul>
                                    <li class="del-link">

                                        <form action="<?php echo e(route('Article.destroy',['Article'=>$ar->id] )); ?>"  method="POST"  >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="buttons pointer"  >
                                                <input type="submit" class="bt3" value="حذف" >
                                            </div>
                                        </form>

                                    </li>

                                    <li class="see"><a href="<?php echo e(route('Article.edit',['Article'=>$ar->id,'user'=>$user->id])); ?>">ویرایش</a></li>
                                </ul>
                            </div>

                            <div class="right">

                                <div class="pic">
                                    <img src="<?php echo e(asset('/src/article/images').'/per'.$ar->image); ?>" alt="">
                                </div>

                                <div class="text">
                                    <h3><a href="<?php echo e(route('home.single.article',$ar->id)); ?>"><?php echo e($ar->title); ?> </a></h3>
                                    <div class="date">
                                        <span>
                                            <?php echo e(\Morilog\Jalali\Jalalian::forge($ar->created_at)->format('%B %d، %Y')); ?>

                                        </span>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>


                </li>
                <li>

                    <div class="article-lits">

                        <?php $__currentLoopData = $artices_deactive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="single-article-ad">

                                <div class="left">
                                    <ul>
                                        <li class="del-link">

                                            <form action="<?php echo e(route('Article.destroy',['Article'=>$ar->id] )); ?>"  method="POST"  >
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <div class="buttons pointer"  >
                                                    <input type="submit" class="bt3" value="حذف" >
                                                </div>
                                            </form>

                                        </li>
                                        
                                        <li class="see"><a href="<?php echo e(route('Article.edit',['Article'=>$ar->id,'user'=>$user->id])); ?>">ویرایش</a></li>
                                    </ul>
                                </div>

                                <div class="right">

                                    <div class="pic">
                                        <img src="<?php echo e(asset('/src/article/images').'/'.$ar->image); ?>" alt="">
                                    </div>

                                    <div class="text">
                                        <h3><a href="<?php echo e(route('home.single.article',$ar->id)); ?>"><?php echo e($ar->title); ?>  </a></h3>
                                        <div class="date">
                                        <span>
                                            <?php echo e(\Morilog\Jalali\Jalalian::forge($ar->created_at)->format('%B %d، %Y')); ?>

                                        </span>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>


                </li>
                <li>

                    <div class="com-lits">


                        <div class="ho-comment">
                            <div class="right">
                                <img src="/home/images/person5.jpg" alt="">
                            </div>

                            <div class="mtexct">
                                <div class="right">
                                    <div class="name"><span>توسط : یلدا شیرازی</span></div>
                                    <div class="date"><span>3:10 PM جمعه - ۲۳ خرداد ۱۳۹۹</span></div>
                                    <div class="text">
                                        <p>سلام، این یک نوشته یک دیدگاه است. سلام، این یک نوشته یک دیدگاه است.  سلام، این یک نوشته یک دیدگاه است. </p>
                                    </div>
                                </div>
                                <div class="buuton">
                                    <span class="remove">حذف<i class="icon-trash"></i></span>
                                    <span class="reply">پاسخ<i class="icon-reply"></i></span>
                                </div>
                            </div>
                        </div>

                        <div class="ho-comment">
                            <div class="right">
                                <img src="/home/images/person5.jpg" alt="">
                            </div>

                            <div class="mtexct">
                                <div class="right">
                                    <div class="name"><span>توسط : یلدا شیرازی</span></div>
                                    <div class="date"><span>3:10 PM جمعه - ۲۳ خرداد ۱۳۹۹</span></div>
                                    <div class="text">
                                        <p>سلام، این یک نوشته یک دیدگاه است. سلام، این یک نوشته یک دیدگاه است.  سلام، این یک نوشته یک دیدگاه است. </p>
                                    </div>
                                </div>
                                <div class="buuton">
                                    <span class="remove">حذف<i class="icon-trash"></i></span>
                                    <span class="reply">پاسخ<i class="icon-reply"></i></span>
                                </div>
                            </div>
                        </div>

                        <div class="ho-comment">
                            <div class="right">
                                <img src="/home/images/person5.jpg" alt="">
                            </div>

                            <div class="mtexct">
                                <div class="right">
                                    <div class="name"><span>توسط : یلدا شیرازی</span></div>
                                    <div class="date"><span>3:10 PM جمعه - ۲۳ خرداد ۱۳۹۹</span></div>
                                    <div class="text">
                                        <p>سلام، این یک نوشته یک دیدگاه است. سلام، این یک نوشته یک دیدگاه است.  سلام، این یک نوشته یک دیدگاه است. </p>
                                    </div>
                                </div>
                                <div class="buuton">
                                    <span class="remove">حذف<i class="icon-trash"></i></span>
                                    <span class="reply">پاسخ<i class="icon-reply"></i></span>
                                </div>
                            </div>
                        </div>

                    </div>


                </li>

            </ul>

        </div>

    </div>


<?php if (isset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02)): ?>
<?php $component = $__componentOriginal405004b71fef127582a15064122221f6b5f1ca02; ?>
<?php unset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/profile/articles.blade.php ENDPATH**/ ?>