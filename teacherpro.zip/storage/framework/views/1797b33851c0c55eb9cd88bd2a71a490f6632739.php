<?php $__env->startSection('main_body'); ?>




    <div id="maincontent" class="rows">
        <div>

            <div id="teacher-page">
                <div id="teacher-top">

                </div>

                <div id="teacher-sidebar">
                    <div class="teacher-inform">
                        <div class=" shade">


                            <div class="pic">
                                <img src="<?php echo e(asset('/src/avatar/'.$user->attr('avatar'))); ?>" alt="">
                            </div>

                            <div class="name">
                                <h2> <?php echo e($user->name); ?></h2>
                                <span>عضویت از
                               <?php echo e(\Morilog\Jalali\Jalalian::forge($user->created_at)->ago()); ?>

                                </span>
                            </div>

                            <div class="free">
                                <div class="right">
                                    <i class="icon-question"></i>
                                    <span>جلسه آزمایشی</span>
                                </div>
                                <div class="left">

                                    <span>
                                        <?php echo e(__('arr.'.$user->attr('freeclass'))); ?>



                                    </span>
                                </div>
                            </div>

                            <div class="course-price">
                                <div class="right">
                                    <i class="icon-question"></i>

                                </div>
                                <div class="left">
                                    <span class="title">رزرو کلاس آنلاین</span>
                                    <span class="text">قیمت هر جلسه (هر ساعت)</span>
                                    <div class="price">
                                        <span class="num"> <?php echo e(number_format($user->com_price($user->meet1))); ?> </span>
                                        <span>ریال</span>
                                    </div>

                                </div>
                            </div>
                            <div class="ovh">
									<span class="reserv-button">
										رزرو کلاس
									</span>
                            </div>
                        </div>

                    </div>

                    <div class="teacher-summerise">
                        <div class="title">
                            <h4>خلاصه اطلاعات مدرس  :</h4>
                        </div>
                        <ul>
                            <li>
                                <div>
										<span class="img">
											<img src="/home/images/surface.svg" alt="">
										</span>
                                    <span class="name">حضور در کلاس</span>
                                    <span class="percent">86%</span>
                                </div>
                            </li>
                            <li>
                                <div>
										<span class="img">
											<img src="/home/images/star.svg" alt="">
										</span>
                                    <span class="name">امتياز</span>
                                    <span class="percent">86%</span>
                                </div>
                            </li>
                            <li>
                                <div>
										<span class="img">
											<img src="/home/images/calendar.svg" alt="">
										</span>
                                    <span class="name">تاريخ عضويت</span>
                                    <span class="percent">  <?php echo e(\Morilog\Jalali\Jalalian::forge($user->created_at)->format('%B %d، %Y')); ?></span>
                                </div>
                            </li>
                            <li>
                                <div>
										<span class="img">
											<img src="/home/images/clock.svg" alt="">
										</span>
                                    <span class="name">شروع به موقع</span>
                                    <span class="percent">86%</span>
                                </div>
                            </li>
                            <li>
                                <div>
										<span class="img">
											<img src="/home/images/surface2.svg" alt="">
										</span>
                                    <span class="name">كلاس به زبان آموز</span>
                                    <span class="percent">86%</span>
                                </div>
                            </li>
                            <li>
                                <div>
										<span class="img">
											<img src="/home/images/surface1.svg" alt="">
										</span>
                                    <span class="name">كل كلاس ها</span>
                                    <span class="percent">86%</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div id="teacher-details">

                    <div class="teacher-info">
                        <ul>
                            <li class="classes">
                                <span class="tex">کلاس های برگزاری شده</span>
                                <span class="number">45</span>
                            </li>

                            <li class="students">
                                <span class="tex">زبان آموزان</span>
                                <span class="number">36</span>
                            </li>

                            <li class="points">
                                <span class="tex">امتیاز</span>
                                <span class="rate">

										<i class="icon-star gray"></i>
										<i class="icon-star gray"></i>
										<i class="icon-star"></i>
										<i class="icon-star"></i>
										<i class="icon-star"></i>
										<span class="av">3/5</span>
										<span>از ۹ نظر</span>

									</span>
                            </li>

                            <li class="lang">
                                <span class="text">	زبان تدریس</span>
                                <ul>
                                    <?php $__currentLoopData = $user->languages()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><img style="height: 25px;width: 25px;" src="<?php echo e(asset('/src/img/lang/'.$lang->img)); ?>" alt=""><span><?php echo e($lang->name); ?></span></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>

                        </ul>
                    </div>

                    <div class="teacher-about">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-write"></i></span>
                            <h3>درباره من</h3>
                        </div>
                        <div class="about-text">
                            <div>
                                <?php echo $user->bio; ?>








                            </div>
                        </div>
                        <div class="about-more">
                            <div>

                                <span> خواندن ادامه</span>
                                <span class="down">
										<i class="icon-down"></i>
										<i class="icon-down"></i>
									</span>
                            </div>
                        </div>
                    </div>

                    <div class="teacher-video">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-play"></i></span>
                            <h3>ویدیو معرفی</h3>
                        </div>
                        <video id="player" class="js-player" playsinline controls data-poster="<?php echo e(asset('src/port_img/'.$user->attr('port_img'))); ?>">
                            <source src="<?php echo e(asset('src/port_vid/'.$user->attr('port_vid'))); ?>" type="video/mp4" />

                        </video>

                    </div>

                    <div class="teacher-nav">
                        <div>
                            <div>

                                <ul>
                                    <li><a href="#teacher-scadule">زمان های آزاد استاد</a></li>
                                    <li><a href="#teacher-expert">حوزه تخصص</a></li>
                                    <li><a href="#teacher-resume">رزومه</a></li>
                                    <li><a href="#teacher-course">دوره‌ها و کلاس‌ها</a></li>
                                    <li><a href="#teacher-blog">مقالات آموزشی</a></li>
                                    <li><a href="#teacher-comments">نظرات</a></li>
                                </ul>

                            </div>
                        </div>
                    </div>

                    <div class="tnav" id="teacher-scadule">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-resume"></i></span>
                            <h3>زمان های آزاد استاد</h3>
                        </div>

                        <div class="teacher-guide">
                            <div class="row">
                                <div class="col-lg-3 col-md-12">
                                    <div>
                                        <div class="title">
												<span>
													راهنمای تقویم :
												</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12">
                                    <div>
                                        <ul>
                                            <li>
                                                <span class="titl">قابل رزرو</span>
                                                <span class="color green"></span>
                                            </li>
                                            <li>
                                                <span class="titl">رزروشده</span>
                                                <span class="color gray"></span>
                                            </li>
                                            <li>
                                                <span class="titl">غیرفعال</span>
                                                <span class="color wgray"></span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-12">
                                    <div>
                                        <div class="time-zone">
                                            <i class="icon-timezone"></i>
                                            <span>منطقه زمانی :</span>
                                            <span>Asia/Tehran</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="teacher-clander" data-name="<?php echo e($user->name); ?>" data-job="<?php echo e(($user->attr('experienced'))?'(مجرب)':''); ?> <?php echo e(($user->attr('motivated'))?'(با انگیزه)':''); ?>  <?php echo e(($user->attr('accepted'))?'(پذیرفته شده)':''); ?>" data-pic="<?php echo e(asset('/src/avatar/'.$user->attr('avatar'))); ?>">
                            <div class="right">
                                <div class="hours">
                                    <ul>
                                        <li>
                                            <span>AM</span>
                                            <span>07:00</span>
                                        </li>
                                        <li>
                                            <span>AM</span>
                                            <span>08:00</span>
                                        </li>
                                        <li>
                                            <span>AM</span>
                                            <span>09:00</span>
                                        </li>
                                        <li>
                                            <span>AM</span>
                                            <span>10:00</span>
                                        </li>
                                        <li>
                                            <span>AM</span>
                                            <span>11:00</span>
                                        </li>
                                        <li>
                                            <span>AM</span>
                                            <span>12:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>13:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>14:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>15:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>16:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>17:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>18:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>19:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>20:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>21:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>22:00</span>
                                        </li>
                                        <li>
                                            <span>PM</span>
                                            <span>23:00</span>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="con">

                                <ul class=" owl-carousel owl-theme ">
                                    <?php for($i=0 ;$i<12;$i++): ?>
                                    <li data-date=" <?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::now()->addDay($i))->format('%A, %d %B  ')); ?> ">

                                        <div class="date">
                                            <span class="top"> </span>
                                            <span class="bot">
                                          <?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::now()->addDay($i))->format('%A, %d %B  ')); ?>

                                           </span>
                                        </div>

                                        <?php for($p=0 ;$p<34;$p++): ?>

                                            <?php
                                                $today= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                                $today2= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                                $today4= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                                $today3= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                                $today5= \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00');
                                            ?>

                                               <?php if($today->addMinutes(($p*30))->greaterThan(\Carbon\Carbon::now() )): ?>





                                                            <div data-level="student" data-id="<?php echo e($user->id); ?>"    class="hour <?php echo e(($user->empty($today2->addMinutes(($p*30))->format('Y-m-d H:i:s')))?' open ':' '); ?>  <?php echo e(($user->reserved($today5->addMinutes(($p*30))->format('Y-m-d H:i:s')))?'  reserved  ':'  '); ?>" data-cid="<?php echo e($user->empty($today4->addMinutes(($p*30))->format('Y-m-d H:i:s'))); ?>"  data-da="<?php echo e(\Morilog\Jalali\Jalalian::forge(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30)))->format('%A, %d %B ')); ?>"  data-time="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))->format('H:i:s')); ?>" >


                                                <input type="checkbox" form="plan" class="op" name="reserve[]" value="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))); ?>" hidden  >
                                            </div>
                                                                                        <?php else: ?>
                                                <div   class="hour <?php echo e(($user->empty($today3->addMinutes(($p*30))->format('Y-m-d H:i:s')))?'   ':''); ?>" data-time="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))->format('H:i:s')); ?>" >
                                                    <input type="checkbox" form="plan" class="op" name=" " value="<?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', \Carbon\Carbon::now()->addDay($i)  ->format('Y-m-d').' 07:00:00')->addMinutes(($p*30))); ?>" hidden  >
                                                </div>
                                                                                    <?php endif; ?>
                                        <?php endfor; ?>


                                    </li>
                                     <?php endfor; ?>

                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="tnav" id="teacher-expert">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-expertis"></i></span>
                            <h3>حوضه تخصص مدرس</h3>
                        </div>

                        <div class="expertis">
                            <ul>
                                <li class="title">
                                    <span>سطوح تدریس</span>
                                </li>
                                <li class="contn">
                                    <div class="row">
                                        <?php
                                        $expert=array('Starter','Elementary','Intermediate','Upper_intermediate','Advanced','Mastery' );
                                        ?>
                                        <?php $__currentLoopData = $expert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($user->attr($ex))): ?>
                                                    <div class="col-lg-6 col-md-12">
                                                        <div>
                                                            <span>(<?php echo e(($user->attr($ex)?__('arr.'.$ex):'')); ?>)</span>
                                                        </div>
                                                    </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>

                                <li class="title">
                                    <span>لهجه مدرس</span>
                                </li>
                                <li class="contn">
                                    <div class="row">
                                        <?php
                                        $expert=array('American_Accent','British_Accent','Australian_Accent','Indian_Accent','Irish_Accent','Scottish_Accent','South_African_Accent' );
                                        ?>
                                        <?php $__currentLoopData = $expert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($user->attr($ex))): ?>
                                                <div class="col-lg-6 col-md-12">
                                                    <div>
                                                        <span>(<?php echo e(($user->attr($ex)?__('arr.'.$ex):'')); ?>)</span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </li>
                                <li class="title">
                                    <span>سن</span>
                                </li>
                                <li class="contn">
                                    <div class="row">
                                        <?php
                                        $expert=array('Children','Teenagers','Adults'  );
                                        ?>
                                        <?php $__currentLoopData = $expert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($user->attr($ex))): ?>
                                                <div class="col-lg-6 col-md-12">
                                                    <div>
                                                        <span>(<?php echo e(($user->attr($ex)?__('arr.'.$ex):'')); ?>)</span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                                <li class="title">
                                    <span>کلاس شامل چه  مواردی میشود</span>
                                </li>
                                <li class="contn">
                                    <div class="row">
                                        <?php
                                        $expert=array('Curriculum','Homework','Learning_Materials','Writing_Exercises','Lesson_Plans','Proficiency_Assessment','Quizzes_Tests','Reading_Exercises' );

                                        ?>
                                        <?php $__currentLoopData = $expert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($user->attr($ex))): ?>
                                                <div class="col-lg-6 col-md-12">
                                                    <div>
                                                        <span>(<?php echo e(($user->attr($ex)?__('arr.'.$ex):'')); ?>)</span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                                <li class="title">
                                    <span>موضوعات</span>
                                </li>
                                <li class="contn">
                                    <div class="row">
                                        <?php
                                        $expert=array('Business_English','Interview_Preparation','Reading_Comprehension'
                                        ,'Listening_Comprehension','Speaking_Practice','Writing_Correction','Vocabulary_Development'
                                        ,'Grammar_Development','Academic_English','Accent_Reduction','Phonetics' );
                                        ?>
                                        <?php $__currentLoopData = $expert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($user->attr($ex))): ?>
                                                <div class="col-lg-6 col-md-12">
                                                    <div>
                                                        <span>(<?php echo e(($user->attr($ex)?__('arr.'.$ex):'')); ?>)</span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </li>
                                <li class="title">
                                    <span>آمادگی برای آزمون</span>
                                </li>
                                <li class="contn">
                                    <div class="row">
                                        <?php
                                        $expert=array('TOEFL','IELTS','PTE'
                                        ,'GRE','CELPIP','Duolingo','TOEIC'
                                        ,'KET','PET','CAE','FCE' ,'CPE' ,'BEC','TOEFLPhD',
                                        'TCF','TEF','DELF'
                                        ,'DALF',
                                            'Goethe','Telc','Test_Daf','OSD','TOMER','TYS','DELE','SIELE'

                                        );

                                        ?>
                                        <?php $__currentLoopData = $expert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($user->attr($ex))): ?>
                                                <div class="col-lg-6 col-md-12">
                                                    <div>
                                                        <span>(<?php echo e(($user->attr($ex)?__('arr.'.$ex):'')); ?>)</span>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="tnav" id="teacher-resume">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-resume"></i></span>
                            <h3>رزومه </h3>
                        </div>

                        <div class="resume-section">
                            <div class="title">
                                <h4>
                                    <i class="icon-tahsil"></i>
                                    <span>سوابق تحصیلی</span>
                                </h4>
                            </div>
                            <ul>
                                <?php $__currentLoopData = $user->resumes()->whereType('education')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="resume">
                                        <div class="right">
                                            <span><?php echo e($resume->from); ?></span>
                                        </div>
                                        <div class="left">
                                            <h5>
                                                <?php echo e($resume->place); ?> : <?php echo e($resume->title); ?>

                                            </h5>

                                            <p>
                                                <?php echo e($resume->info); ?>

                                            </p>
                                            <span class="date">
													<span>     <?php echo e($resume->from); ?><?php echo e($resume->till); ?></span>
													<i class="icon-time-line"></i>
												</span>
                                        </div>
                                    </div>
                                </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$user->resumes()->whereType('education')->get()->first()): ?>
                                        <div class="no-vontent">
                                            <img src="/home/images/resume.svg" alt="">
                                            <span>هنوز رزومه ای  ثبت نشده</span>
                                        </div>
                                    <?php endif; ?>

                            </ul>
                        </div>

                        <div class="resume-section">
                            <div class="title">
                                <h4>
                                    <i class="icon-sabegh"></i>
                                    <span>سوابق کاری</span>
                                </h4>
                            </div>
                            <ul>
                                <?php $__currentLoopData = $user->resumes()->whereType('sabeghe')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="resume">
                                            <div class="right">
                                                <span><?php echo e($resume->from); ?></span>
                                            </div>
                                            <div class="left">
                                                <h5>
                                                    <?php echo e($resume->place); ?> : <?php echo e($resume->title); ?>

                                                </h5>

                                                <p>
                                                    <?php echo e($resume->info); ?>

                                                </p>
                                                <span class="date">
													<span>     <?php echo e($resume->from); ?><?php echo e($resume->till); ?></span>
													<i class="icon-time-line"></i>
												</span>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$user->resumes()->whereType('education')->get()->first()): ?>
                                    <div class="no-vontent">
                                        <img src="/home/images/resume.svg" alt="">
                                        <span>هنوز رزومه ای  ثبت نشده</span>
                                    </div>
                                <?php endif; ?>

                            </ul>
                        </div>

                        <div class="resume-section">
                            <div class="title">
                                <h4>
                                    <i class="icon-licence"></i>
                                    <span>گواهی‌ها</span>
                                </h4>
                            </div>
                            <ul>
                                <?php $__currentLoopData = $user->resumes()->whereType('licence')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="resume">
                                            <div class="right">
                                                <span><?php echo e($resume->from); ?></span>
                                            </div>
                                            <div class="left">
                                                <h5>
                                                    <?php echo e($resume->place); ?> : <?php echo e($resume->title); ?>

                                                </h5>

                                                <p>
                                                    <?php echo e($resume->info); ?>

                                                </p>
                                                <span class="date">
													<span>     <?php echo e($resume->from); ?><?php echo e($resume->till); ?></span>
													<i class="icon-time-line"></i>
												</span>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$user->resumes()->whereType('education')->get()->first()): ?>
                                    <div class="no-vontent">
                                        <img src="/home/images/resume.svg" alt="">
                                        <span>هنوز رزومه ای  ثبت نشده</span>
                                    </div>
                                <?php endif; ?>

                            </ul>
                        </div>


                    </div>

                    <div class="tnav" id="teacher-course">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-folder"></i></span>
                            <h3>دوره‌های ویدیویی</h3>
                        </div>
                        <div class="teacher-course-list">
                            <ul class="owl-carousel owl-theme">

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>
                            </ul>

                        </div>
                    </div>

                    <div class="tnav" id="teacher-course">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-folder"></i></span>
                            <h3>کلاس‌های گروهی آنلاین</h3>
                        </div>
                        <div class="teacher-course-list">
                            <ul class="owl-carousel owl-theme">

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>

                                <li>
                                    <div class="scourse">
                                        <div class="cats">
                                            <a href="#">علوم کامپیوتر</a>
                                        </div>
                                        <div class="title">
                                            <h3>اموزش طراحی قالب وردپرس</h3>
                                        </div>
                                        <div class="img">
                                            <a href="#">
                                                <img src="/home/images/course.jpg" alt="">
                                            </a>
                                        </div>
                                    </div>
                                </li>
                            </ul>

                        </div>
                    </div>

                    <div class="tnav" id="teacher-blog">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-author"></i></span>
                            <h3>مقالات منتشر شده  توسط استاد</h3>
                        </div>
                        <div class="blog-list">
                            <ul class="owl-carousel owl-theme">
                                <?php $__currentLoopData = $user->articles()->whereActive('1')->whereSubmit('1')->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li>
                                    <div class="single-blog">
                                        <div class="right">
                                            <a href="#">
                                                <img src="<?php echo e(asset('src/article/images/articles'.$article->image)); ?>" alt="">
                                            </a>
                                        </div>
                                        <div class="left">
                                            <h3><a href="#"> <?php echo e($article->title); ?> </a></h3>
                                            <div class="date">
                                                <span>On</span>
                                                <span><?php echo e($article->created_at); ?></span>
                                            </div>
                                            <div class="text">
                                                <p>
                                                    <?php echo $article->article; ?>

                                                </p>
                                            </div>
                                            <div class="more">
                                                <a href="#"> خواندن ادامه <i class="icon-left"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                    </div>

                    <div class="tnav" id="teacher-comments">
                        <div class="t-icon-title">
                            <span class="icon"><i class="icon-commento"></i></span>
                            <h3>دیدگاه های زبان آموزان (۱ نظر)</h3>
                        </div>

                        <div class="right-avrage">
                            <div class="title">
                                <h3>
                                    <span>%86</span>
                                    <span>رضایت</span>
                                </h3>
                            </div>
                            <ul>
                                <li>
                                    <div class="left">
                                        <i class="icon-sohappy"></i>
                                    </div>
                                    <div class="right">
                                        <div class="bar"><span style="width: 40%"></span></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="left">
                                        <i class="icon-happy"></i>
                                    </div>
                                    <div class="right">
                                        <div class="bar"><span style="width: 50%"></span></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="left">
                                        <i class="icon-mood"></i>
                                    </div>
                                    <div class="right">
                                        <div class="bar"><span style="width: 30%"></span></div>
                                    </div>
                                </li>
                                <li>
                                    <div class="left">
                                        <i class="icon-sad"></i>
                                    </div>
                                    <div class="right">
                                        <div class="bar"><span style="width: 77%"></span></div>
                                    </div>
                                </li>
                            </ul>
                            <div class="avr">
                                <span>امتیاز  :</span>
                                <span>از 13 نظر</span>
                            </div>
                            <div class="points">
                                <i class="icon-star gray"></i>
                                <i class="icon-star gray"></i>
                                <i class="icon-star"></i>
                                <i class="icon-star"></i>
                                <i class="icon-star"></i>
                                <span>3/5</span>
                            </div>
                        </div>

                        <div class="comment-list">
                            <ul class="owl-carousel owl-theme">
                                <li>
                                    <div class="single-comment">
                                        <div class="pic">
                                            <i class="icon-comment"></i>
                                            <img src="/home/images/person1.jpg" alt="">
                                        </div>
                                        <div class="name">
                                            <span>سمانه خرّمی</span>
                                        </div>
                                        <div class="job">
                                            <span>دانشجوی نرم افزار</span>
                                        </div>
                                        <div class="text">
                                            <p>استاد بسیار خوبی هستند روش تدریس شون به گونه ای بود که مباحث رو خیلی خوب می فهمیدم. من تا به الان با ايشون 18 جلسه کلاس داشتم که با کمک استاد و همت خودم به نتیجه مطلوب برسم</p>
                                        </div>
                                        <div class="date">
												<span>
													پنج‌شنبه ۲۵ اردیبهشت ۰۷:۵۷
												</span>
                                        </div>
                                        <div class="point">
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single-comment">
                                        <div class="pic">
                                            <i class="icon-comment"></i>
                                            <img src="/home/images/person2.jpg" alt="">
                                        </div>
                                        <div class="name">
                                            <span>Mohamad Hasan</span>
                                        </div>
                                        <div class="job">
                                            <span>دانشجوی رشته تحلیل داد</span>
                                        </div>
                                        <div class="text">
                                            <p> شیوه درس دادن استاد بسیار عالی و مفید بوده و از  ادب و متانت و سواد بالاشون بسیار راضی ام و این موضوع روی پیشرفت من موثر بوده </p>
                                        </div>
                                        <div class="date">
												<span>
													نج‌شنبه ۲۵ اردیبهشت ۰۷:۵۷
												</span>
                                        </div>
                                        <div class="point">
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single-comment">
                                        <div class="pic">
                                            <i class="icon-comment"></i>
                                            <img src="/home/images/person1.jpg" alt="">
                                        </div>
                                        <div class="name">
                                            <span>Erfan Amade</span>
                                        </div>
                                        <div class="job">
                                            <span>زبان آموز</span>
                                        </div>
                                        <div class="text">
                                            <p>  در همون جلسه اول متوجه شدیم استاد از تسلط بالایی برخوردار هستن و قدرت بیان عالي  دارند. واقعا راضی بودیم و نتیجه هم شگفت انگيز بود.</p>
                                        </div>
                                        <div class="date">
												<span>
													پنج‌شنبه ۲۵ اردیبهشت ۰۷:۵۷
												</span>
                                        </div>
                                        <div class="point">
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single-comment">
                                        <div class="pic">
                                            <i class="icon-comment"></i>
                                            <img src="/home/images/person4.jpg" alt="">
                                        </div>
                                        <div class="name">
                                            <span>Mohamad Hasan</span>
                                        </div>
                                        <div class="job">
                                            <span>دانشجوی رشته تحلیل داد</span>
                                        </div>
                                        <div class="text">
                                            <p> شیوه درس دادن استاد بسیار عالی و مفید بوده و از  ادب و متانت و سواد بالاشون بسیار راضی ام و این موضوع روی پیشرفت من موثر بوده </p>
                                        </div>
                                        <div class="date">
												<span>
													پنج‌شنبه ۲۵ اردیبهشت ۰۷:۵۷
												</span>
                                        </div>
                                        <div class="point">
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="single-comment">
                                        <div class="pic">
                                            <i class="icon-comment"></i>
                                            <img src="/home/images/person5.jpg" alt="">
                                        </div>
                                        <div class="name">
                                            <span>Mohamad Hasan</span>

                                        </div>
                                        <div class="job">
                                            <span>دانشجوی رشته تحلیل داد</span>
                                        </div>
                                        <div class="text">
                                            <p>استاد بسیار خوبی هستند روش تدریس شون به گونه ای بود که مباحث رو خیلی خوب می فهمیدم. من تا به الان با ايشون 18 جلسه کلاس داشتم که با کمک استاد و همت خودم به نتیجه مطلوب برسم</p>
                                        </div>
                                        <div class="date">
												<span>
													پنج‌شنبه ۲۵ اردیبهشت ۰۷:۵۷
												</span>
                                        </div>
                                        <div class="point">
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star gray"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                            <i class="icon-star"></i>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                </div>

            </div>

        </div>
    </div>
















    <div class="popupc" id="level1_<?php echo e($user->id); ?>">
        <div>
            <div>
                <div>

                    <div class="popup-container shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>

                        <div class="procecss-steps level1">
                            <ul>
                                <li class="step1">
                                    <span class="left"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>انتخاب جلسه</h4>
                                </li>
                                <li class="step2">
                                    <span class="left"></span>
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>انتخاب زمان</h4>
                                </li>
                                <li class="step3">
                                    <span class="left"></span>
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>قوانین کلاس ها</h4>
                                </li>
                                <li class="step4">
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>روش پرداخت</h4>
                                </li>
                            </ul>
                        </div>
                        <?php if($user->attr('freeclass') !='noclass'): ?>
                        <div class="class-price">
                            <div class="lable-container">
                                <input type="radio" data-count="0" data-sum="<?php echo e($user->com_price($user->free_class_price())); ?>"
                                       name="class_type" id="freeclass" value="freeclass">
                                <label for="freeclass">
                                    <div class="right">
                                        <h4>جلسه آزمایشی</h4>
                                        <span>‏30 دقیقه کلاس آنلاین</span>
                                    </div>
                                    <div class="left">
                                        <div class="button-container reight gray">
                                            <span class="butt">
                                            <?php echo e(number_format($user->com_price($user->free_class_price()))); ?>

                                            ریال / ساعتی</span>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="class-price">

                            <div class="lable-container">
                                <input type="radio"   data-count="1" data-sum="<?php echo e($user->com_price($user->meet1)); ?>"  name="class_type" id="session1" value="meet1">
                                <label for="session1">
                                    <div class="right">
                                        <h4>‏1 جلسه</h4>
                                        <span>‏1 ساعت کلاس آنلاین</span>
                                    </div>
                                    <div class="left">
                                        <div class="button-container reight gray">
                                            <span class="butt">
                                                 <?php echo e(number_format($user->com_price($user->meet1))); ?>


                                                ریال / ساعتی</span>
                                        </div>
                                    </div>
                                </label>
                            </div>

                        </div>

                        <div class="class-price">

                            <div class="lable-container">
                                <input type="radio"  data-count="5"   data-sum="<?php echo e($user->com_price($user->meet5)); ?>"  name="class_type" id="session5" value="meet5">
                                <label for="session5">
                                    <div class="right">
                                        <h4>‏5 جلسه</h4>
                                        <span>‏5 ساعت کلاس آنلاین</span>
                                    </div>
                                    <div class="left">
                                        <div class="button-container reight gray">
                                            <span class="butt">‏
                                                 <?php echo e(number_format($user->com_price($user->meet5))); ?>


                                                  / ساعتی</span>
                                        </div>
                                    </div>
                                </label>
                            </div>

                        </div>

                        <div class="class-price">

                            <div class="lable-container">
                                <input type="radio"  data-count="10"  data-sum="<?php echo e($user->com_price($user->attr('meet10'))); ?>" name="class_type" id="session10" value="meet10">
                                <label for="session10" class="eco">
                                    <div class="right">
                                        <h4>‏10 جلسه<span>اقتصادی ترین</span></h4>
                                        <span>‏10 ساعت کلاس آنلاین</span>
                                    </div>
                                    <div class="left">
                                        <div class="button-container reight gray">
                                            <span class="butt">‏‏
                                                 <?php echo e(number_format($user->com_price($user->attr('meet10')))); ?>


                                                 / ساعتی</span>
                                        </div>
                                    </div>
                                </label>
                            </div>

                        </div>

                        <div class="nextstep">
                            <div class="left">
                                <img src="<?php echo e(asset('/src/avatar/'.$user->attr('avatar'))); ?>" alt="">
                            </div>
                            <div class="right">
                                <div class="eteb">
                                    <ul>
                                        <li>جمع پرداختی</li>
                                        <li>
                                            <span class="sum"></span>
                                            ریال
                                        </li>
                                    </ul>
                                </div>
                                <ul class="etmen">
                                    <li>
                                        <div class="button-container reight">
                                            <span class="butt go_level_2" data-id="<?php echo e($user->id); ?>" id="">مرحله بعد</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="button-container reight gray">
                                            <span class="butt close_popup">بازگشت به عقب</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>



    <div class="popupc" id="level2_<?php echo e($user->id); ?>">
        <div>
            <div>
                <div>

                    <div class="popup-container mini shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>

                        <div class="session-pop">
                            <div class="top">

                                <h3>
                                    انتخاب زمان برگزاری اولین جلسه
                                </h3>
                                <p>
                                    زمان اولین کلاس را الان انتخاب میکنید، دقت کنید که زمانبندی جلسات بعدی در پنل کاربری شما انجام خواهد شد
                                </p>

                            </div>
                            <div class="bot">
                                <div class="right">
                                    <img src="/home/mages/time.png" alt="">
                                </div>
                                <div class="left">
                                    <div class="teacher-guide">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-12">
                                                <div>
                                                    <div class="title">
														<span>
															راهنمای تقویم :
														</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-12">
                                                <div>
                                                    <ul>
                                                        <li>
                                                            <span class="titl">قابل رزرو</span>
                                                            <span class="color green"></span>
                                                        </li>
                                                        <li>
                                                            <span class="titl">رزروشده</span>
                                                            <span class="color gray"></span>
                                                        </li>
                                                        <li>
                                                            <span class="titl">غیرفعال</span>
                                                            <span class="color wgray"></span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="button-container reight">
                                <?php if(\Illuminate\Support\Facades\Auth::check()): ?>

                                <span   data-id="<?php echo e($user->id); ?>"  class="butt go_level_3">متوجه شدم</span>
                                    <?php else: ?>
                                    <span   data-id="<?php echo e($user->id); ?>" id="force_login"  class="butt  ">متوجه شدم</span>


                                <?php endif; ?>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>


    <div class="popupc" id="level3_<?php echo e($user->id); ?>" >
        <div>
            <div>
                <div>

                    <div class="popup-container shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>



                        <div class="nextstep">
                            <div class="left">
                                <img src="<?php echo e(asset('/src/avatar/'.$user->attr('avatar'))); ?>" alt="">
                            </div>
                            <div class="right">
                                <div class="eteb">
                                    <ul>
                                        <li>زمان انتخابی شما  :</li>
                                        <li class="ico"><i class="icon-calender"></i><span class="s_time">    </span></li>

                                    </ul>
                                </div>
                                <ul class="etmen">
                                    <li>
                                        <div class="button-container reight">
                                            <span   data-id="<?php echo e($user->id); ?>" class="butt go_level_4">مرحله بعد</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="button-container reight gray">
                                            <span   data-id="<?php echo e($user->id); ?>" class="butt go_level_2">بازگشت به عقب</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>



    <div class="popupc"  id="level4_<?php echo e($user->id); ?>">
        <div>
            <div>
                <div>

                    <div class="popup-container shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>

                        <div class="procecss-steps level3">
                            <ul>
                                <li class="step1">
                                    <span class="left"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>انتخاب جلسه</h4>
                                </li>
                                <li class="step2">
                                    <span class="left"></span>
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>انتخاب زمان</h4>
                                </li>
                                <li class="step3">
                                    <span class="left"></span>
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>قوانین کلاس ها</h4>
                                </li>
                                <li class="step4">
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>روش پرداخت</h4>
                                </li>
                            </ul>
                        </div>


                        <div class="check-rules">
                            <div class="right">
                                <img src="/home/images/weather_two_color.png" alt="">
                            </div>
                            <div class="left">
                                <ul>
                                    <li><p>در روز کلاس جهت هماهنگی با شما تماس گرفته خواهد شد. در صورت عدم پاسخگویی پس از دو مرتبه تماس کلاس تان <strong>لغو</strong> خواهد شد</p></li>
                                    <li><p> در زمان رزرو شده به موقع در کلاس تان حضور پیدا کنید. <strong> تا 15 دقیقه استاد در کلاس منتظر شما</strong> خواهد بود و در صورت عدم حضور، کلاس به عنوان برگزارشده تلقی خواهد شد.</p></li>
                                    <li><p> امکان حضور در کلاس با تمامی سیستم عامل ها و مرورگرها  <strong>به جز موبایل آیفون</strong> در حال حاضر امکان پذیر است.</p></li>
                                </ul>
                            </div>
                        </div>





                        <div class="nextstep">
                            <div class="left">
                                <img src="images/person1.jpg" alt="">
                            </div>
                            <div class="right">
                                <div class="eteb">
                                    <ul>
                                        <li>زمان انتخابی شما  :</li>
                                        <li class="ico"><i class="icon-calender"></i><span class="s_time">    </span></li>
                                    </ul>
                                </div>
                                <ul class="etmen">
                                    <li>
                                        <div class="button-container reight">
                                            <span   data-id="<?php echo e($user->id); ?>" class="butt go_level_5">مرحله بعد</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="button-container reight gray">
                                            <span  data-id="<?php echo e($user->id); ?>" class="butt go_level_3">بازگشت به عقب</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>




    <div class="popupc"  id="level5_<?php echo e($user->id); ?>">
        <div>
            <div>
                <div>

                    <div class="popup-container shade">
						<span class="close">
							<i class="icon-cancel"></i>
						</span>

                        <div class="procecss-steps level4">
                            <ul>
                                <li class="step1">
                                    <span class="left"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>انتخاب جلسه</h4>
                                </li>
                                <li class="step2">
                                    <span class="left"></span>
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>انتخاب زمان</h4>
                                </li>
                                <li class="step3">
                                    <span class="left"></span>
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>قوانین کلاس ها</h4>
                                </li>
                                <li class="step4">
                                    <span class="right"></span>
                                    <span class="cir"><i class="icon-tick"></i></span>
                                    <h4>روش پرداخت</h4>
                                </li>
                            </ul>
                        </div>


                        <div class="waypoint">

                            <div class="right">
                                <div class="profile">
                                    <div class="pic">
                                        <img src="<?php echo e(asset('/src/avatar/'.$user->attr('avatar'))); ?>" alt="">
                                    </div>
                                    <div class="det">
                                        <h4>نسیم کدخدایان</h4>
                                        <span>‏60 دقیقه آموزش آنلاین</span>
                                    </div>
                                </div>

                                <div class="totall">
                                    <ul>
                                        <li class="r">مبلغ کل :</li>
                                        <li class="l"><span class="sum">    </span><span>ریال</span></li>
                                    </ul>
                                </div>












                                <div class="payable">
                                    <ul>
                                        <li class="r">مبلغ قابل پرداخت :</li>
                                        <li class="l">
                                            <span class="sum green">    </span>
                                            <span>ریال</span></li>
                                    </ul>
                                </div>

                                <div class="button-container reight full">
                                    <span class="butt" id="send_pay_for_meet">پرداخت</span>
                                </div>

                            </div>
                            <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                            <form action="<?php echo e(route('student.charge.wallet',auth()->user()->id)); ?>" method="post" id="pay_for_meet">
                                <?php else: ?>
                                    <form   method="post" id="pay_for_meet">
                                <?php endif; ?>
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('post'); ?>
                                <input type="text" name="count" id="count_meet"  >
                                <input type="text" name="time" id="time_meet"  >
                                <input type="text" name="fst" id="fst"   >
                            <div class="left">

                                <h3>روش پرداخت را انتخاب کنید</h3>


                                <div class="bank">

                                    <div class="lable-container">
                                        <input type="radio" name="bank" id="ses1" value="bank">
                                        <label for="ses1">
                                            <div class="right">
                                                <div class="pic"><img src="/home/images/saman.png" alt=""></div>
                                                <h4>‏درگاه بانکی</h4>
                                            </div>
                                            <div class="left">
                                                <div class="button-container reight gray">
                                                    <span class="butt">
                                                                    <span class="sum"></span>
                                                        ریال / ساعتی</span>
                                                </div>
                                            </div>
                                        </label>
                                    </div>

                                </div>


                                <div class="bank">

                                    <div class="lable-container">
                                        <input type="radio" name="bank" id="ses2" value="wallet">
                                        <label for="ses2">
                                            <div class="right">
                                                <div class="pic"><img src="/home/images/wallet.png" alt=""></div>
                                                <h4>‏ کیف پول تیچر پرو</h4>
                                            </div>
                                            <div class="left">
                                                <div class="button-container reight gray">
                                                    <span class="butt">
                                                                   <span class="sum"></span>
                                                        ریال / ساعتی</span>
                                                </div>
                                            </div>
                                        </label>
                                    </div>

                                </div>

                                <div class="bank-text">
                                    <ul>
                                        <li>پس از پرداخت موفق خواهید توانست زمان کلاس های خود را از روی تقویم استاد به صورت یکجا و یا تدریجی انتخاب نمایید.</li>
                                        <li>پس از پرداخت موفق، در صورت عدم رضایت امکان تغییر استاد نیز وجود دارد.</li>
                                    </ul>
                                </div>


                            </div>


                            </form>


                        </div>





                    </div>

                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/teacher_profile.blade.php ENDPATH**/ ?>
