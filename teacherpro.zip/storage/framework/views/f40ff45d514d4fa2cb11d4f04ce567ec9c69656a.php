<?php $__env->startSection('main_body'); ?>

    <div id="maincontent" class="rows sfix">
        <div>



    <?php echo $__env->make('home.student.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="teacherpish">
    <?php echo e($bread); ?>





        <div class="welcome">
            <span class="name"> <?php echo e(auth()->user()->name); ?></span>
            <span>خوش آمدید؛
            <?php echo e(\Morilog\Jalali\Jalalian::forge('today')->format('%A %d %B ')); ?>


            </span>
        </div>





    <?php echo e($slot); ?>

    </div>




        </div>
   </div>

    <!-- /.content -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\teacherpro\resources\views/home/student/content.blade.php ENDPATH**/ ?>