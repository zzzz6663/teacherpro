<?php $__env->startComponent('admin.section.content',['title'=>' تنظیمات  ']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item"><a href="/admin">پنل مدیریت</a></li>
        <li class="breadcrumb-item"> تنظیمات     </li>
    <?php $__env->endSlot(); ?>
    <?php

    $setting = new \App\Models\Setting();
//    dd($setting->set('password'));
    ?>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <!-- left column -->
                <div class="col-md-6">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  تنظیمات ورود</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->



                        <form role="form" method="post" action="<?php echo e(route('admin.login.info')); ?>">
                            <?php echo method_field('post'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body">

                                <div class="form-group">
                                    <label for="exampleInputEmail1"> Username     </label>
                                    <input type="text" value="<?php echo e(old('username',$setting->set('username'))); ?>"   name="username" class="form-control" id="exampleInputEmail1" placeholder="    Username  ">
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputPassword1">Password</label>

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->


                </div>
                <!--/.col (left) -->
                <!-- right column -->
                <!-- left column -->

                <!--/.col (left) -->
                <div class="col-md-6">
                    <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">  حداقل و حداکثر قیمت </h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        
                        
                        
                        <form role="form" method="post" action="<?php echo e(route('admin.teacher.save.max.min')); ?>">
                            <?php echo method_field('post'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body">

                                <div class="form-group">
                                    <label for="max_price"> max price teacher     </label>
                                    <input type="text" value="<?php echo e(old('max_price',$setting->set('max_price'))); ?>"   name="max_price" class="form-control" id="max_price" placeholder="    max_price  ">
                                    <?php $__errorArgs = ['max_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="min_price">min price teacher </label>
                                    <input type="text"  value="<?php echo e(old('max_price',$setting->set('min_price'))); ?>"  name="min_price" class="form-control" id="min_price" placeholder=" min_price">
                                    <?php $__errorArgs = ['min_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">ارسال</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->


                </div>
                <!-- right column -->

            </div>

            <!-- /.row -->
        </div><!-- /.container-fluid -->


        <div class="row">
            <div class="col-md-12">
                <div class="card card-danger">
                    <div class="card-header">
                        <h3 class="card-title">بازه های قیمتی برای تعیین کمسیون</h3>
                    </div>
                    <form role="form" method="post" action="<?php echo e(route('admin.teacher.save.period')); ?>">
                        <?php echo method_field('post'); ?>
                        <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <?php for($i=1;$i<8;$i++): ?>
                        <div class="row">
                           <div class="col-md-12">
                               <div class="row">

                               <div class="col-6 form-group">
                                   <label for="period<?php echo e($i); ?>">period<?php echo e($i); ?>

                                   </label>
                                   <span class="tx"></span>
                                   <input type="number" name="period<?php echo e($i); ?>"   value="<?php echo e(old('period'.$i,$setting->set('period'.$i))); ?>"  class="form-control money" placeholder="13000">

                                   <?php $__errorArgs = ['period'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <div class="alert alert-danger"><?php echo e($message); ?></div>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               </div>
                                   <?php if($i<7): ?>
                               <div class="col-6 form-group">
                                   <label for="wage<?php echo e($i); ?>">wage<?php echo e($i); ?>

                                   </label>
                                   <span class="tx"></span>
                                   <input type="number" name="wage<?php echo e($i); ?>"   value="<?php echo e(old('wage'.$i,$setting->set('wage'.$i))); ?>"  class="form-control money" placeholder="13000">

                                   <?php $__errorArgs = ['wage'.$i];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <div class="alert alert-danger"><?php echo e($message); ?></div>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               </div>
                                   <?php endif; ?>

                               </div>

                           </div>



                        </div>
                        <?php endfor; ?>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">save</button>
                    </div>
                    </form>
                    <!-- /.card-body -->
                </div>
            </div>
        </div>
    </section>

<?php if (isset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c)): ?>
<?php $component = $__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c; ?>
<?php unset($__componentOriginale1985a1e425ca739ea92bf00a6b1a7539c52068c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\teacherpro\resources\views/admin/setting.blade.php ENDPATH**/ ?>