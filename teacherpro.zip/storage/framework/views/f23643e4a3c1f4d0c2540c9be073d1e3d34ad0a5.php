<?php $__env->startComponent('home.teacher.content',['title'=>' تنظیمات  ']); ?>


<div id="teacherpish">

    <?php $__env->slot('bread'); ?>


        <?php echo $__env->make('home.teacher.profile.bread_left',['name'=>'    قیمت ها   '], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $__env->endSlot(); ?>





            <div class="teacher-pricing shade">

                <div class="widget-title">
                    <h3> قیمت گذاری جلسات (تومان)</h3>

                    <div class="dot3">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>

                <div class="widget-content">

                    <div class="row">

                        <div class="col-lg-6 col-md-12">
                            <div>

                                <?php if($errors->any()): ?>
                                    <div class="e_section" id="e_section">
                                        <?php if($errors->any()): ?>
                                            <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('teacher.save.price',$teacher->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <div class="input-container fill">
                                        <label for="">قیمت یک جلسه</label>
                                        <input type="number" value="<?php echo e(old('meet1',$teacher->attr('meet1'))); ?>"  name="meet1" class="money" placeholder=" 650,000 ریال">
                                        <div class="tx"><?php echo e(old('meet1',$teacher->attr('meet1'))); ?> ریال</div>

                                    </div>

                                    <div class="input-container fill">
                                        <label for="">قیمت هر جلسه از دوره 5 جلسه ای</label>
                                        <input type="number" value="<?php echo e(old('meet5',$teacher->attr('meet5'))); ?>"  name="meet5" class="money" placeholder="650,000 ریال">
                                        <div class="tx"><?php echo e(old('meet5',$teacher->attr('meet5'))); ?> ریال</div>


                                    </div>

                                    <div class="input-container fill">
                                        <label for="">قیمت هر جلسه از دوره 10جلسه ای</label>
                                        <input type="number" value="<?php echo e(old('meet10',$teacher->meet10)); ?>"  name="meet10" class="money" placeholder="650,000 ریال">
                                        <div class="tx"><?php echo e(old('meet10',$teacher->meet10)); ?> ریال</div>


                                    </div>

                                    <div class="button-container reight">
                                        <input type="submit" value="ذخیره تغییرات" class="bt">

                                    </div>
                                </form>

                            </div>
                        </div>

                        <div class="col-lg-6 col-md-12">
                            <div>
                                <img src="/home/images/finance_analysis_.png" alt="">
                            </div>
                        </div>

                    </div>
                </div>

            </div>

            <div class="teacher-pricing-free shade">

                <div class="widget-title">
                    <h3>وضعیت جلسه آزمایشی</h3>

                    <div class="dot3">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>

                <div class="widget-content">

                    <div class="row">
                        <div class="col-lg-12">
                            <div>
                                <p class="light-text">جلسه آزمایشی ، یک جلسه 30 دقیقه ای برای آشنایی دانشجو با شماست </p>
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-lg-6 col-md-12">
                            <div>
                                <img src="/home/images/maskroup.png" alt="">
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-12">
                            <div>



                                <?php if($errors->any()): ?>
                                    <div class="e_section" id="e_section">
                                        <?php if($errors->any()): ?>
                                            <?php echo implode('', $errors->all('<span class="text text-danger">:message</span><br>')); ?>

                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>






                                <form action="<?php echo e(route('teacher.save.more.price',$teacher->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>

                                    <div class="check-buttonlist">
                                        <ul>
                                            <li>
                                                <div class="lable-container">
                                                    <input type="radio" name="freeclass"   <?php echo e((old('freeclass') == 'free'  || $teacher->attr('freeclass')=='free') ? 'checked' : ''); ?> id="free" value="free">
                                                    <label for="free">
                                                        <div class="right">
                                                            <span>رایگان  <span class="l">(توصیه پرو تیچر)</span></span>
                                                        </div>
                                                        <div class="left">
                                                            <div class="circle">
                                                                <span></span>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="lable-container">
                                                    <input type="radio" name="freeclass"   <?php echo e((old('freeclass') == 'nofree'  || $teacher->attr('freeclass')=='nofree') ? 'checked' : ''); ?> id="nofree" value="nofree">
                                                    <label for="nofree">
                                                        <div class="right">
                                                            <span>غیر رایگان</span>
                                                        </div>
                                                        <div class="left">
                                                            <div class="circle">
                                                                <span></span>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                            <li>
                                                <div class="lable-container">
                                                    <input type="radio" name="freeclass"   <?php echo e((old('freeclass') == 'noclass'  || $teacher->attr('freeclass')=='noclass') ? 'checked' : ''); ?> id="noclass" value="noclass">
                                                    <label for="noclass">
                                                        <div class="right">
                                                            <span>عدم اراِئه</span>
                                                        </div>
                                                        <div class="left">
                                                            <div class="circle">
                                                                <span></span>
                                                            </div>
                                                        </div>
                                                    </label>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <div class="input-container clas_sec fill" <?php echo e((old('freeclass') == 'nofree' || $teacher->attr('freeclass')=='nofree') ? '' : 'hidden'); ?>  >
                                        <!-- <label for="">قیمت هر جلسه از دوره 10جلسه ای</label> -->
                                        <input type="number" class="money" value="<?php echo e(old('free_meeting_price',$teacher->attr('free_meeting_price'))); ?>"  name="free_meeting_price" placeholder="‏650,000 ریال">
                                        <div class="tx"><?php echo e(old('free_meeting_price',$teacher->attr('free_meeting_price'))); ?> ریال</div>
                                    </div>

                                    <div class="button-container reight">
                                        <input type="submit" value="ذخیره تغییرات" class="bt">
                                    </div>
                                </form>

                            </div>
                        </div>

                    </div>
                </div>

            </div>

            <div id="faqs">
                <h2>چه قیمتی را برای کلاس هایم تعیین کنم؟</h2>

                <p class="subtitle">کلاسهای آنلاین ارزانتر از کلاس های حضوری :</p>

                <div class="faqs">


                    <div class="faq">
                        <div class="question tran">
                            <h4> <i class="icon-question-o"></i>
                                کلاسهای آنلاین ارزانتر از کلاس های حضوری :
                            </h4>
                        </div>
                        <div class="answer">
                            <p>
                                باتوجه به تکنولوژی های پیشرفته اتیچر، هر کلاس یک ساعته که استاد و زبان آموز هر دو به صورت صوتی-تصویری کلاس خود را برگزار کنند، تنها حدودا 200 مگابایت دیتا مصرف خواهد شد( همچون یک تماس معمولی در واتساپ یا ایمو).


                            </p>
                        </div>

                    </div>

                    <div class="faq">
                        <div class="question tran">
                            <h4> <i class="icon-question-o"></i>
                                کلاسهای 60 دقیقه ای :
                            </h4>
                        </div>
                        <div class="answer">
                            <p>
                                باتوجه به تکنولوژی های پیشرفته اتیچر، هر کلاس یک ساعته که استاد و زبان آموز هر دو به صورت صوتی-تصویری کلاس خود را برگزار کنند، تنها حدودا 200 مگابایت دیتا مصرف خواهد شد( همچون یک تماس معمولی در واتساپ یا ایمو).


                            </p>
                        </div>

                    </div>

                    <div class="faq">
                        <div class="question tran">
                            <h4> <i class="icon-question-o"></i>
                                کلاسهای آنلاین ارزانتر از کلاس های حضوری :
                            </h4>
                        </div>
                        <div class="answer">
                            <p>
                                باتوجه به تکنولوژی های پیشرفته اتیچر، هر کلاس یک ساعته که استاد و زبان آموز هر دو به صورت صوتی-تصویری کلاس خود را برگزار کنند، تنها حدودا 200 مگابایت دیتا مصرف خواهد شد( همچون یک تماس معمولی در واتساپ یا ایمو).


                            </p>
                        </div>

                    </div>


                    <div class="faq">
                        <div class="question tran">
                            <h4> <i class="icon-question-o"></i>
                                نگران مصرف بالای دیتای اینترنت نباشید :
                            </h4>
                        </div>
                        <div class="answer">
                            <p>
                                باتوجه به تکنولوژی های پیشرفته اتیچر، هر کلاس یک ساعته که استاد و زبان آموز هر دو به صورت صوتی-تصویری کلاس خود را برگزار کنند، تنها حدودا 200 مگابایت دیتا مصرف خواهد شد( همچون یک تماس معمولی در واتساپ یا ایمو).


                            </p>
                        </div>

                    </div>

                    <div class="faq">
                        <div class="question tran">
                            <h4> <i class="icon-question-o"></i>
                                کلاسهای آنلاین ارزانتر از کلاس های حضوری :
                            </h4>
                        </div>
                        <div class="answer">
                            <p>
                                باتوجه به تکنولوژی های پیشرفته اتیچر، هر کلاس یک ساعته که استاد و زبان آموز هر دو به صورت صوتی-تصویری کلاس خود را برگزار کنند، تنها حدودا 200 مگابایت دیتا مصرف خواهد شد( همچون یک تماس معمولی در واتساپ یا ایمو).


                            </p>
                        </div>

                    </div>


                </div>
            </div>





</div>



    <?php if (isset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02)): ?>
<?php $component = $__componentOriginal405004b71fef127582a15064122221f6b5f1ca02; ?>
<?php unset($__componentOriginal405004b71fef127582a15064122221f6b5f1ca02); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\teacherpro\resources\views/home/teacher/profile/prices.blade.php ENDPATH**/ ?>
